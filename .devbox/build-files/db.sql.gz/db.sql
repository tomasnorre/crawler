-- MariaDB dump 10.19  Distrib 10.5.17-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.5.17-MariaDB-1:10.5.17+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `widgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1671173172,1671173172,2,0,0,0,0,'2d6f8fa1cb984078485e9b8ac3c8cef52a250818','My dashboard','{\"e30c302ce680963eb14459b30e648b99acc7090c\":{\"identifier\":\"t3information\"},\"7d677e509e669efa10355ecd5294e2a73246d95f\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pagetypes_select` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tables_select` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `availableWidgets` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mfa_providers` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('03ee5cd286a2401596b43ffdd7e386bd19058f1f7af7dfc0dcb94fe580372e91','[DISABLED]',2,1671274129,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"aaa65b0e0d6eef3c0c68889b96a158a87699c841365aa1b98430826940727178\";}'),('04640c6fab10ce67c3392d3bf83fd361a6d371b16f5f1b850212e03aad33aeb8','[DISABLED]',2,1671274449,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"69d646d246cbccc1bd811b3442d34aa13f5b5bc3ec8d2e041be6c0355a18243a\";}'),('0afcf52f16031dc4387f4b9fba23b9e3cd0257dc88c254c052afeb9c524caaa7','[DISABLED]',2,1671274352,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2cbbb8a7be6a473b25bc1a6c112ea3aae52c29d43d9896097cd71e0baa84ebc4\";}'),('0e50ad8f7146d823b12c3328490f8587dd65682512d0fb3204de2c6f08d9bcf7','[DISABLED]',2,1671275959,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"742d768feb1112374c7d119772bf3d2095bea942ca438279862c36cf0de2da78\";}'),('0f326a82d19dfe7fc303e2e543777d57f739dfb6923c75f1e5008d2995412d77','[DISABLED]',2,1671268893,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"afbfebdee508c5e51433560c5a4d8c7f646597aa284248cd9d0e0b7d902b692d\";}'),('0fd5a6465378b44e7597356ee67f84e30fa9e1e42013a6513fc50dddcdc06c0a','[DISABLED]',2,1671274225,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2119c372d1d03d7f2346b04d5d1067de20f4b766257c6387258f26a5dbe6d48f\";}'),('10b4a045fd94c22f3687fc8a1fd7d59d99a0cf5f9581333af595fab736c50631','[DISABLED]',2,1671267589,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"161473cc023040d7ec4e3b679224727fdb54fa3d23a9087867c7c1b249620bd4\";}'),('17f98490dbede45dca659892787ace0a195353e2042108e6b57986694dffdba1','[DISABLED]',2,1671274138,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"3552555eedf3ad94ca5353aedb8adfae9185ec8e43dc6adf61e69a1292583635\";}'),('1853dea1a4a863118dc0b477042d02d8e3b716ac9efaaac4acbb8a506b724866','[DISABLED]',2,1671274398,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"5ec6a9a8d5aadcfd95a7eb30866e449c250417ead86fd602578462a6341faa5a\";}'),('191d0aa3b819917b518c6485e1051d7e933c57c0b080df3a11b0a10d90622231','[DISABLED]',2,1671269045,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"c3e68b695ae29d22d22416377e019f587ff98c73d24b40633782d8ac96f7c0c4\";}'),('1d0e63b044402b51af74c3540d9a03c9bc1706bb51b0d692c8f5db14149749e6','[DISABLED]',2,1671267676,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"5d903f9c172d535e9e448e8c9f3f6115177d516bdaf237db5115eb6ae5280a41\";}'),('1d3205a6f0ba333e970042a72c5b0fea8ba45fca076138fc30c573656d3c82d4','[DISABLED]',2,1671273941,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"39fa8c664c5d79eb8d6c6e40f1bd1572e2f7a33c182daf04d42ea9311e81c504\";}'),('21065b77c58dade5e7a45c4641d6a5421e35fa8ee0090047d031641bd7ae7ac9','[DISABLED]',2,1671273972,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"d92749de371e21c6c1a0270ca45c926b55bbc76b17304bed1861992493cd8822\";}'),('2106e8cb67c94ea820151bbfaa83c76a0b587f62c0b1cffaf061e6af691ab6ca','[DISABLED]',2,1671274232,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"d68cbd49b3f60bafa3d99dcc51cd531942ae8dfd21c3c5963416b65f48075a58\";}'),('23f8c6bf064d3a2b52b0cc5dbf254549e24f6236d061557c47372a021e898cf4','[DISABLED]',2,1671268635,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"7dc56478ed0d6037348a6a12a597993df5a95a15af77febcbc5b7b4ffbf45636\";}'),('267638eba5f5f72ae14ad8330557ff512fd07e23c4546c512018e071836d8ae5','[DISABLED]',2,1671274440,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"aee008a80ede0b5a0edc0d66f078032d6d00cf1bec3c3a993af93d5ab542ca2e\";}'),('2ac508f0153477748f3332f385a987cde1f2e1e04b11280984b89dcde591e751','[DISABLED]',2,1671267525,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"59f25c766a04ad3a7ce0f9b0cb2cdc02b5e0c618ac0216e7014b7d4b5bc307eb\";}'),('2dee55ca8e046a7153c4c4fab2557f6879480333725ab6d3a36da3ce04c59a9e','[DISABLED]',2,1671267726,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"b445f7d4158ae9044829ebd7fd2329d76d2bd2bdd3493abcf656f981917e0f8f\";}'),('2f9fb26fe183d7fbc085e726ed1d946dbcbfa46593b55c5de4dd088b7a475dff','[DISABLED]',2,1671272532,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"6418d28a387b6f689ab048f89fe9cef2ff23ad015604bcf320e1bd733db0c128\";}'),('36efe7ac5541cd74b35460111a22c5acff3ca55a2ceced08c943c74efe8aff2b','[DISABLED]',2,1671274294,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"53532fcd6aee3ce2ad3ac160d548872d79838252676422d0493e0d72e90b541d\";}'),('39ff4e62a1bd9b97e9bf9c65f13562a3c88848b87db3a0f1bcd729fbcbc5a4c5','[DISABLED]',2,1671267695,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"47ac14c9c21b2043d4461dfe9f95b4e212a2ac3dc252aa6be62221339c8e2158\";}'),('3b24e4eb6c6941b8e3ee107a2c02722cb2448c6cea012a891a99ab153a5adb8a','[DISABLED]',2,1671268026,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8dddba058259fe4ea818d934698a3e415edf5f3e3297c91c8b4310a927d7c786\";}'),('42894f4781321d7a1587aeebfd360bdb49b857898c0a5359a65821be79458f15','[DISABLED]',2,1671267513,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2f55fe89c6b4283323cd9078ca3feb29ebf91cf5066c9c59c590e5a8c54c6c5c\";}'),('4413a03b2ca76f325247bcfd5e8513d611a420158a58877cc54085b3cb38e167','[DISABLED]',2,1671272333,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8c129ac48c6295b2ec666d44326cb13512253b6ed8246330171acbc84fa27584\";}'),('467fc219296111e4d64a84b089b1bc3c43fedb1952ca1f6c9ca658651cbab845','[DISABLED]',2,1671272068,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"6e24fa7921866fb4ff5c5a9cc2db7f4729809f63d7e4f91a6148588e1e0b618f\";}'),('48779a644f19729ead1dea6bc0eb9345ef8a7c46361bb9b7e91d53889362e513','[DISABLED]',2,1671267599,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"92a5d2862c6cfbb93832ffd7e0e6b4902beda089e7d2539ebc47de527e7974ce\";}'),('48bf2afba7206e1434de30f71ccdd21930d004c008c160ef566d53ccbed39844','[DISABLED]',2,1671274066,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"41b0fb095fe2e2e2366b338946514829e95b35b1e3290eef688fb6fb74628f66\";}'),('4c8e3ab9304ee80dbda09b36bda6aa07167444f0a394b4c334cff44c64e64059','[DISABLED]',2,1671268161,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"745a83b949ecadbcf85f472277fbef2546600a57aeba7d094919258444bb8a21\";}'),('4d78fb1da54c0cf25640270a741f4ec785d84c2f34250ffd06317966fd0eeacb','[DISABLED]',2,1671267641,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"f41633e7d4b789dc0bea449108d3475f0de0f6077d71b1ce0a9d882926263460\";}'),('4daed5d95035e82d08a1df26e88a1668b07ffc8886cb3d497ccd3b00ef8053ce','[DISABLED]',2,1671267461,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"3fd944cbea4f021f1708c502b26523cd51135bc2f51f51041986aa9af5d839f6\";}'),('4f6730913fe592703458681c17c6af0d1d0ab3026d9aad934dd2616ac88b2cac','[DISABLED]',2,1671274009,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"7b0abaa47ed942854480b3fdd88c3b4735b6b1b84c329ce34136c4f856565ba7\";}'),('5088f9e291e9575e26317cd86c9041b9bab98a0b60c9ff248646b3d8a80de8db','[DISABLED]',2,1671275808,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"5fa57653efb3faad09a6c21556c0a3ecbd172d95b8d82b0350092166d401f8f6\";}'),('52be441cefba1870df352f9d4b95c0da3bcf561fbdf760e4f08b890e4069efed','[DISABLED]',2,1671268353,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2d54b19bd65e16094347ae6cad1e57006b57659588ba515e9b1cde0cbb450363\";}'),('5a861b65dd13b6999d36eab9f0dc64c8a457862236b775c233bdabef02bc6ff1','[DISABLED]',2,1671274022,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"92146ad7bcb3e1cf310916a3dd849bd5e00bb903ccd8e75b00a0efdd78988423\";}'),('5f2c6b4b2a3a5fd788b0a5bfc4b465194114f41708a4fbb5e22ec7b29991e733','[DISABLED]',2,1671274380,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"fbd10ae69a9ce22775df12cabd0eee231eaadff6c1976ee4fdad90ebf5ddad82\";}'),('616c36078f3a5c465f5a61753cbb143d35d1104bb98f164edabe79e593cb1a17','[DISABLED]',2,1671274427,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"38382a11bf39fb5c5f7a1f32303ec75bf764cd7a202e078251083dfc3cddf04a\";}'),('651782e8af4ee8b01f05ebcb2bea1b655c82aa3cc11b718ee94f65256000c6f4','[DISABLED]',2,1671274366,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8f4cdbf32887c8d723b45f2a69778c1eaccdc87d4bd7263a6fbe9af46df27b28\";}'),('66740dabb4d0e3b3e8340a35cc4fd2baa5778f098ad18b4d92a29595800e9361','[DISABLED]',2,1671274044,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"254c104a9512d38a36e3a74280040125cbaced4bbf7823e34de4f8621abfa6c1\";}'),('678805ac09c4432c4157b6b971b7693d2e6b8b2a33b09e9220a16059d326c542','[DISABLED]',2,1671267621,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8d108ff52f2c638f7c7f2a230d485019b202a3a00dbaf6e2a04aae4a7b53f6dd\";}'),('764aa889dcfd3042964c15f1136506cfb1a1ba6022942ed01b6293f8a629b303','[DISABLED]',2,1671267554,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"fca7cb3e78f204ef68f863a5150ac420edd77cf508d6363a9e38b39f1731b58d\";}'),('7af1ac2a222eadaf533cdd3c26abccef4aa5488c05baf40336722e69ff25afef','[DISABLED]',2,1671285921,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2f28014dd98562856255a6a94fabef5638e48947cc8bba663c9d58493709301d\";}'),('7ef69b9a42540dfbc6760b467254dccef81b81231d6cd105865c76a9e34097ae','[DISABLED]',2,1671274079,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"1eb9e9c4ab298037c9169a0607dd7b115b5d2c4eb8fb9ec96cc2151248e94174\";}'),('871437c1b9e76a64db4419c3fe26f2d76e4bf1c0d67c0d981373fb054397c463','[DISABLED]',2,1671267456,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"1da4752d8de9f6e1a079e85b6a5ca6746f2e1191b38e2fd14f2c63d74d0ce4d8\";}'),('873162099e4ffd164fe80d8d260a8f844c270cbaf54ea238020d24cb27e869ec','[DISABLED]',2,1671267499,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"fe31220356b32a382fd0a9aa7ce501827cda02bd8fd78c1a943f7996d9368100\";}'),('8f7190272b975b86fe59924152488513f0f0787b6a85f996fa06db531538cf13','[DISABLED]',2,1671272292,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"5de2a44faa309e671075b76fe19868db8f9f9715b9520c6e459ea237c2337ad7\";}'),('96a1d8ca7a5c63dc790b3e98aa32f9f737e25fadcaa7cdaa25de228b8f5fd26d','[DISABLED]',2,1671273937,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2198465ad4f06b9535693b163e91ae14120b182b8cc17b06e090af47fa60288e\";}'),('9dcd3c30d50749d1edb3a072eff2db0c6cca1eae5ccaff4eda37da798a42922a','[DISABLED]',2,1671274240,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"66603fe82d9abb0a0d7406d7512c022526d91d3c80c59ae564b2c0984e0811ed\";}'),('9e29d5d984e27022826e35bb348dfab084640db2ac773c49941071a6fe27e32d','[DISABLED]',2,1671274054,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"3a41953c8220d7fcd09c0f048620d6e3f69aaf34fd42840d57fe76596648026f\";}'),('a400233eea98cb84b28666dcfadefbdd7867f12d5a3cfa0b9fd4d90eb7ebcaa2','[DISABLED]',2,1671274222,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"685a4ff09629068a5566055392042a31487f485f4a3f4bb764688a8a8dbc985c\";}'),('a6204915c1fc1e3b4fec55c14cee3a918d280b515e7dbc661f4602fa06b0e3b4','[DISABLED]',2,1671267609,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"f968ba31fe9acab08221aac2721b9bc686ebd548c1ba0c632cb3ae3793c499a9\";}'),('a8f2fd39f1f1ff14efe3a52c01b842f0dfa366d8b5af2829a539a6368da4f8c0','[DISABLED]',2,1671274034,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"1ed722d5e49497f11a65a10760388fa9f155b5e0aa5539eb2d5214791aa006d9\";}'),('a9db7155042b58a9dd9e70481c70a655e6730179991a15ab762bd7618f9d1e2b','[DISABLED]',2,1671274329,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"0ff3cb63213c487e77c57b2239c9e7181d97924cbac34e767d66d00e36a620ee\";}'),('aa497b07e16efd6bdcbbae0ea4cb31242cc8b70563e612e3567e1822ba1bd0b4','[DISABLED]',2,1671274267,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"7aef7986a8f168f078483c9c38ce2937213dfd7a5af45c2eb0a774e4d89dc2fc\";}'),('b2fa50bee6e78c4e2c71d2b92d9988bedbceea5c64d0ad6aa905b254807561fc','[DISABLED]',2,1671274248,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"fc36ff6c71f0bcda40c00dc5ea8ebef1231a713bcf73eb693adc76a8c7592ebe\";}'),('b39b3ff0a60d1358c7c9c11e38a516c2e31c2c7fa41f662a38465444844d1ba8','[DISABLED]',2,1671273990,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8448af178c4aa4421dcf8d858d07c5206eac413e8ffd78c51e60a5f13810f219\";}'),('b4f379e19d500bbb79c99976e982a82210503ec116670362fc25e5955409c695','[DISABLED]',2,1671274110,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"af4527b072808477b8ebe636611f6bc1a4d242a2f16e24d675541d49e9f182e1\";}'),('bad2f6dec023665d98c22a85d847ed2b7c8c5dde04b149da860835df0a063baa','[DISABLED]',2,1671267658,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"a8054883411020e6e1b88291f0d01ee77b7aa322d6eacd1aa325d12b6e8c9876\";}'),('baf297925ba5e99f6eee39d4c92ff4da1eb932c120572f1b5db582ce581d4f59','[DISABLED]',2,1671273948,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"bbf77f65c2c73733b9caf867b826c02cfcb4f97a0989e2e4ad28a4f75471297c\";}'),('bd433d7a592080b1dd6cd796021da8ada5d7e667aa5dfb5fca8e9691e5d5862b','[DISABLED]',2,1671274338,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"e9763336b0cbac23e24220f863db541520c65af097af13a248f79bb844ca037a\";}'),('bec173a9e966684e3e3043150afd0790bcd09d7f314b6650e40d6645d8594e27','[DISABLED]',2,1671273981,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8ba01a7d769154fb5807009241450f78bcf17335d873bb81d6ce6d75eb26a2c5\";}'),('c09f9c0c57290c7b358966da50166d2a72581432e962aca5fed5869cc2da4d8e','[DISABLED]',2,1671274258,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"d040edd8e710ca097ccc20e30ed668af8f069372dfb5d64819c1a9c73a1027b2\";}'),('c3e0ccfe2550c00f1a935cd34eb6573e86c46ffd135303e8b0a138d362d36e40','[DISABLED]',2,1671273963,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2f5584c580d030e20eb194584ea24e824722718672d94af71608ca1f228c5470\";}'),('c4606f3d4f795fcf2cd0e9a669dfda063e62d89ae337d1425412794355c7f336','[DISABLED]',2,1671274418,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2561214980131a1baeb478babb896289695450eaaa4265ab485bbc493f764465\";}'),('cb5234fa614d09257f9ca701f56f5bab62fb3e91c1a41dc62178fb0889dca46c','[DISABLED]',2,1671272354,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"76ca293b1899ffa99dc748f1a093f4e10f44d6461556301e594550612ee4d874\";}'),('cbecca49cf1b3483f6731202559d6710e1b5b7101268c3afcc44a989e85b59d8','[DISABLED]',2,1671267486,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"1aafad4fd1cf1755b35900b5b7b9ac5e01cce86b7bd58716197dd60f3c1e8161\";}'),('d2e7a2f7ccd04574ad547f8d18647be10fbf55bcaf7633f74cc09c2daf0f88ea','[DISABLED]',2,1671274307,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"b4f5ff8d9df23ba711b7039fd0ebd131fcce652c7f51264d614df1d85630bb9b\";}'),('d4b6c8c3976974e88ac924d9b3ef70858e5d5b2a808c3b288e6f3732f09c64cb','[DISABLED]',2,1671273956,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"2ef0de9ff1f06badb2452e927356ad6c71ddaad88f951aaf1d0f73424c288d09\";}'),('d4d72d9f828b889763b09b1f2380812539a784c54044652e922621c20dea487e','[DISABLED]',2,1671267539,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"4495e79ff458a823ca43dec5cefefcad201dbd5826ceb8d6d6c6051de0f0071c\";}'),('d6717ce214a6336e55587165a45e1a0596b440fb81edcd69a797ec62ba5d932f','[DISABLED]',2,1671267564,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"98ac1985bd2a3703bd37fea88c74b83970a7a70110ab050218cd55db484fe56b\";}'),('dd43733bd11dcc26f18b0c47835a9a9bcc317a6a139ff0d4166b531d1f046e4d','[DISABLED]',2,1671274160,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"de0724408a36c488c3b6a060c1934ed55dd85aae54c10a0be5ecfb9b1fa3dc8e\";}'),('e07b90e318879ec26bde8f1b3f74616c9171f4c8c11e9012ab38d581ab203a52','[DISABLED]',2,1671274319,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"807cff91f072d92bb591dc4a5ffb2b6c5d0f0391ce0c326719cd75fc0671c797\";}'),('e326747d095355f138d67b7b33a83a604ad3cdadbc039c01f0d881842f47b914','[DISABLED]',2,1671267703,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"30759ea405624aae5fb7fb16e24dbdc6f0fa7668ea4a6399ad6f2d168b521be0\";}'),('e379dd2f74c139ced62a1b1b50270997bce1a8a3b19a626f6d00112db4c16f20','[DISABLED]',2,1671267717,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"b8afbde892e503ed04ea318761fb1583f86abede53eec90cc971db5fbc28a05e\";}'),('e926e31b8f5849aa59ccbbc1082d5c487b6dd0c283bf5e7510d2d6eecde4e6ab','[DISABLED]',2,1671272191,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"3d253eff38af57d4fa7209dec9cd18642e23a87a6e5b35d75000386351fc008e\";}'),('ec854a4bc5307a108e67af2ad10faf072da12729f07a8fa66c800bf61b5615bf','[DISABLED]',2,1671267931,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"bd27444c32963c3ae0bc640fde5fc264b881bf4b987722e21b1af39f0fdd8f30\";}'),('ee236cef01b7ae4370f795ed8052cc01e474d5aaa480e0af23b5ea03e918fea6','[DISABLED]',2,1671274093,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"844c43452da0774e2a7f2f2c8dcb41566940f9f18d20d9a1ea77e43ffbf5d541\";}'),('f1d252e6f29e7b21010978e3f65a5b18629ff620b2228380dfaf9e8cd4a4b594','[DISABLED]',2,1671267473,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"3510f7decda177d4972315cc073268dd436364104f8b99e0f055b55acbfa5ee3\";}'),('f528acb1a6cb3b793a21d97af1e5b8e4897cd3e05888258fa7b90d6519ac24bf','[DISABLED]',2,1671267577,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"ec8754fc89daf6b80ce4e08e17a09b6e51eed91045b30b107807b67b8ec69802\";}'),('f6846e991b50444191a3910c45222e2f3ce2e90c277ce11cc5b4525280910e1d','[DISABLED]',2,1671273999,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"d236f66cbaf84a21a5528d7898432539caedefda6a36cbb8e0fae42a2edc8831\";}'),('f68f39159cdadd16a1c9b02bcc4522e9e6881fa3875fa77b9931fd7ba94a2a3f','[DISABLED]',2,1671274285,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"9ddadab4833a1615aaf5fad83df8c96ac861684ae2e705971767aa7d691f836d\";}'),('f90f25c6cf063b4cf444ea2f7b1f56403fb934edd8318f8e0d1e8bf788017b04','[DISABLED]',2,1671274276,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"253c9710cf73e2251b0bbcca0201e770ef495febf02963c2fb2be2ffa9ebfd47\";}'),('fce4dff6ab18f84ad5e680bdc952ed415daf0c5bc4117d12b9f04e65a75bb2d2','[DISABLED]',2,1671274151,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"8470924346da9a21a72574da8546f5492da0a6e9c3f395f770b86f83693d1648\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tx_news_categorymounts` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1668273190,1668273190,0,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$NFhuVVVsbWpLNmc3bFRmMg$OZ27hxQ2HUyMH+7OwDK7noVKomneHsmL655nguyb0pA',1,NULL,'default','',NULL,0,'',NULL,'','a:9:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:25:\"resizeTextareas_MaxHeight\";i:500;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1668273190;}',NULL,NULL,1,NULL,0,0,NULL,NULL,'',''),(2,0,1668273241,1668273198,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$N2t4NGhVcFkzUmV3T3BucA$wiWp9d8o2V6GZ8f6uSBDlnzZlUrU9nYGG73V2GxX/Rw',1,NULL,'default','',NULL,0,'',NULL,'','a:11:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:11:{s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:19:\"constant_editor_cat\";N;}s:8:\"web_info\";a:7:{s:8:\"function\";s:33:\"AOE\\Crawler\\Backend\\BackendModule\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;s:5:\"depth\";s:1:\"0\";s:11:\"crawlaction\";s:12:\"multiprocess\";s:11:\"log_display\";s:3:\"all\";s:12:\"itemsPerPage\";s:1:\"5\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:334:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:0:\"\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:8:\"web_list\";a:3:{s:8:\"function\";N;s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"af6a208f792a83220f87a953a62a081a\";a:4:{i:0;s:299:\"Try it\r\n\r\n\r\n\r\n\r\nfunction myFunction() {\r\n  let text = &quot;Press a button!\\nEither OK or Cancel.&quot;;\r\n  if (confirm(text) == true) {\r\n    text = &quot;You pressed OK!&quot;;\r\n  } else {\r\n    text = &quot;You canceled!&quot;;\r\n  }\r\n  document.getElementById(&quot;demo&quot;).innerHTML = text;\r\n}\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"af6a208f792a83220f87a953a62a081a\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"opendocs::recent\";a:4:{s:32:\"fc108f3e67d1783d9f2af765a1f7cdf6\";a:4:{i:0;s:11:\"dsfasdfsdaf\";i:1;a:5:{s:4:\"edit\";a:1:{s:24:\"tx_crawler_configuration\";a:1:{i:7;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:47:\"&edit%5Btx_crawler_configuration%5D%5B7%5D=edit\";i:3;a:5:{s:5:\"table\";s:24:\"tx_crawler_configuration\";s:3:\"uid\";i:7;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"650b3918a6e6f1922310b8e5c5ac84d5\";a:4:{i:0;s:4:\"News\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:11;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B11%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:11;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:16:\"Default Template\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"35774be6e40fbb573fc000769ff42e98\";a:4:{i:0;s:21:\"excludepages-6-plus-3\";i:1;a:5:{s:4:\"edit\";a:1:{s:24:\"tx_crawler_configuration\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:47:\"&edit%5Btx_crawler_configuration%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:24:\"tx_crawler_configuration\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}s:6:\"web_ts\";a:6:{s:8:\"function\";s:72:\"TYPO3\\CMS\\Tstemplate\\Controller\\TemplateAnalyzerModuleFunctionController\";s:8:\"language\";N;s:19:\"constant_editor_cat\";s:7:\"content\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:23:\"ts_browser_showComments\";s:1:\"1\";}s:28:\"dashboard/current_dashboard/\";s:40:\"2d6f8fa1cb984078485e9b8ac3c8cef52a250818\";s:16:\"web_site_crawler\";a:1:{s:6:\"action\";s:20:\"web_site_crawler_log\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:25:\"resizeTextareas_MaxHeight\";i:500;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1668273628;s:15:\"moduleSessionID\";a:11:{s:10:\"web_layout\";s:40:\"f8c85f95feaafab88fa24b2e5eedb59fde7a5779\";s:8:\"web_info\";s:40:\"a539700f9fa1167f890ebac5d71fb6afd7183117\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"cc0791840d2dbd18401515f9ed553edff8b44dd0\";s:8:\"web_list\";s:40:\"990354a0043bb3c7104e6d00407630f614592567\";s:10:\"FormEngine\";s:40:\"75fe8428c2b72de45a6417fd93d0d06d1821b1de\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"75fe8428c2b72de45a6417fd93d0d06d1821b1de\";s:16:\"opendocs::recent\";s:40:\"5328bd18ea253c307a3f631063a9beea6cd2749f\";s:9:\"clipboard\";s:40:\"e7886ddf98b584d23c9cae6b85bcd47c75fe33af\";s:6:\"web_ts\";s:40:\"317acecb31703a15028b7aa508bbeb1a12ed7bc5\";s:28:\"dashboard/current_dashboard/\";s:40:\"7cd5d4c4da4c05adbc5e58fc03e36bac5b961c39\";s:16:\"web_site_crawler\";s:40:\"75fe8428c2b72de45a6417fd93d0d06d1821b1de\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:2:{s:3:\"0_1\";s:1:\"1\";s:3:\"0_7\";s:1:\"1\";}}}}}',NULL,NULL,1,NULL,1671275950,0,NULL,NULL,'',''),(3,0,1668273215,1668273215,0,0,0,0,0,NULL,'tomas',0,'$argon2i$v=19$m=65536,t=16,p=1$VG9LME9nMmtmYUNvalBlbg$GYk9TSL7xiUaw2ToRfJQtXjgapvxG0t9HK9+oj7GrGc',1,NULL,'default','',NULL,0,'',NULL,'','a:12:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:11:{s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:19:\"constant_editor_cat\";N;}s:9:\"tx_beuser\";a:2:{s:15:\"compareUserList\";a:0:{}s:6:\"demand\";a:5:{s:8:\"userName\";s:0:\"\";s:8:\"userType\";i:0;s:6:\"status\";i:0;s:6:\"logins\";i:0;s:16:\"backendUserGroup\";i:0;}}s:10:\"FormEngine\";a:2:{i:0;a:16:{s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:7:\"Welcome\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"7d9e144e24486a6668d151356ea4c9d4\";a:4:{i:0;s:14:\"Frontend Users\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"2258d9587529a9ea12f96ce7d90372b3\";a:4:{i:0;s:5:\"Login\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:3;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:4:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"deac478137dd48a97e299bd046412e21\";a:4:{i:0;s:6:\"Search\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"c72d4a5ffd106794d45e5a4a941814ba\";a:4:{i:0;s:6:\"Search\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:2;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:4:{i:0;s:5:\"Login\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"831786fd4612b658a2e11ed01c306877\";a:4:{i:0;s:5:\"admin\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"fe_users\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bfe_users%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"fe_users\";s:3:\"uid\";i:1;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3af505b920348c1a79bf62ea28cbec90\";a:4:{i:0;s:22:\"Access Restricted Page\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:5;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"a3b9454ecc0d182884b26f9c529ddb87\";a:4:{i:0;s:22:\"Access Restricted Page\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:4;s:3:\"pid\";i:5;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"750043f9a02785cc6557d2efe33fd403\";a:4:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"639c80047818aac48db3b25ab8d3d802\";a:4:{i:0;s:18:\"Page with Subpages\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:7;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B7%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:7;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"2852d3f5b619bb7a4bb2eff52fab7de9\";a:4:{i:0;s:13:\"Subpage Three\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:10;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:16:\"Default Template\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"e47da558d45aabb13d478afc895af27c\";a:4:{i:0;s:7:\"default\";i:1;a:5:{s:4:\"edit\";a:1:{s:24:\"tx_crawler_configuration\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:47:\"&edit%5Btx_crawler_configuration%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:24:\"tx_crawler_configuration\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"494c59ed0b451cdb0042831766e2d4b1\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:5;s:3:\"pid\";i:11;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"494c59ed0b451cdb0042831766e2d4b1\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"opendocs::recent\";a:7:{s:32:\"650b3918a6e6f1922310b8e5c5ac84d5\";a:4:{i:0;s:4:\"News\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:11;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B11%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:11;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"5c1b878c87d518a051ef05bd38d2cccf\";a:4:{i:0;s:7:\"Website\";i:1;a:5:{s:4:\"edit\";a:1:{s:9:\"fe_groups\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:32:\"&edit%5Bfe_groups%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:9:\"fe_groups\";s:3:\"uid\";i:1;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"29de12b3b960c7b9fac10cdbdef2bdfd\";a:4:{i:0;s:4:\"+ext\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:5:\"title\";s:6:\"noView\";N;}i:2;s:53:\"&edit%5Bsys_template%5D%5B2%5D=edit&columnsOnly=title\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:2;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:16:\"Default Template\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"20ed475662b97ac33d3aa853a74f9c9c\";a:4:{i:0;s:6:\"Search\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"f7cbd0e893b561842b8a9fac07c77a5d\";a:4:{i:0;s:8:\"NEW SITE\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:5:\"title\";s:6:\"noView\";N;}i:2;s:53:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=title\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"64ed4aefdecb75409ac4c8e6f107b333\";a:4:{i:0;s:5:\"admin\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bbe_users%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";i:2;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:6:\"web_ts\";a:3:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:8:\"language\";N;s:19:\"constant_editor_cat\";s:0:\"\";}s:8:\"web_list\";a:3:{s:8:\"function\";N;s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}s:16:\"browse_links.php\";a:1:{s:10:\"expandPage\";s:1:\"1\";}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}s:8:\"web_info\";a:7:{s:8:\"function\";s:33:\"AOE\\Crawler\\Backend\\BackendModule\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;s:5:\"depth\";s:2:\"99\";s:11:\"crawlaction\";s:3:\"log\";s:11:\"log_display\";s:3:\"all\";s:12:\"itemsPerPage\";s:1:\"5\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:334:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:0:\"\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:25:\"resizeTextareas_MaxHeight\";i:500;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1668273227;s:15:\"moduleSessionID\";a:11:{s:10:\"web_layout\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:9:\"tx_beuser\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:10:\"FormEngine\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:16:\"opendocs::recent\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:6:\"web_ts\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:8:\"web_list\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:16:\"browse_links.php\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:9:\"clipboard\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:8:\"web_info\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"c7e959058344eacd82069be7bcdadc6d232f8cb8\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:6:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";s:3:\"0_6\";s:1:\"1\";s:3:\"0_2\";s:1:\"1\";s:3:\"0_7\";s:1:\"1\";s:3:\"0_8\";s:1:\"1\";}}}}s:14:\"indexed_search\";a:2:{s:6:\"action\";s:9:\"statistic\";s:9:\"arguments\";a:5:{s:2:\"id\";s:1:\"1\";s:6:\"action\";s:9:\"statistic\";s:10:\"controller\";s:14:\"Administration\";s:4:\"mode\";s:7:\"content\";s:5:\"depth\";s:1:\"1\";}}}',NULL,NULL,1,NULL,1668273227,0,NULL,NULL,'','');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache`
--

LOCK TABLES `cache_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache_tags`
--

LOCK TABLES `cache_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES (16,'redirects_7e3f5fc261021d0c567fe9cb00ff94a3799eb5c8',1671288189,'x�K�2���\0O�'),(17,'redirects_df58248c414f342c81e056b40bee12d17a08bf61',1671288189,'x�K�2���\0O�'),(18,'2_2bfb73cda7b72fbc3cd3b9eb52e99367e6fb8406',1671370989,'x��<is㸱�\Z�\n��|�ZY\"uk<~��O<��I�*�R�$$aL\nAJvv翧	�����m���vGDh4\Z�F7H2�~����&:cA���d�ϣ�FI�:�>4}s�a<����2Y��G�O-$��u�F���:�Q�hBj��Ă&��i2o�M�Q;����0�y�5��&�-t.�h|������K&j[�!B\r~����TҀڵF�Eb�b-jk��!�%�&�C�\r�K�#�yLi��iT<�}Z�q�ޓ�]����Ƿ��%���}͏)IT�%bM��䖐x�?�H�B��H\0<�@���W��__Z]�|}��2�9���\\����kgw �`<icj�r��,��H��m` ۈ�����<^��<8[1�RՐ�%k1j6��5o�x�<h4`b�B���u�Q�����u�9#�J4]�w{q��Kz���^�x�m\ru{A��DsN6H~��נ\n�V���&\nW̏����Pv���O���bzy��x���i+ �p؞���͝�O��C��WCY\r�����Si2��d2��x3yngHwq5��x�l9���Փ)3�w_\'컯���W�����������sr�TN����=��M����Jc��\Z�I��|�%�lY:�GĘg]���P?VKl�m+�n<~wԤ��&���.gyE69ǈ���_ݭlN���\n#d5?���q�^�$-y/���+1�/aI��-_�=����}�`+e�!��G((�����9Q��G�~ձ>:H08=}��}�%��5n��x���Ǉ����0�ilY�l��Çg�\Z�kH[���C/#�DEd���ɔ�G�U�x@M���#j�2[�\nZ�=��v�,��	�O�E�]S����R]���n\n���~����n*�_�>��M(�o�?�Y�\\���`���\0���Kv�pjГ���\ZO(\"��c�3�L�\0G\r¢,t��Z�ScQ*٩9x�p� ��_�(���M�s<������4L��A\Z!�9$�<M\Z�\nSx�A	s�ՔБ\ntw]ĩf^�9Z�,��\n�a7G��~��*�7z��v4�pq5�M�7��ù�vz�~w���^˙��a��;þ��yJOO�(�\"�ԛ�Y?��zm��f�>L�n����S��+���N��הY#L\'9�Q�\'������+2�`�\'sNs�����M�Pe����c�a�?$�N\\���q �l\Z\0�F��+x���O���Oc�O׆�I{��A�� �咯[�wh�Pn��\'ů�X�ңs�C?(�e��Q��}���{���\r�4��Ѷ�\Z<ܑ��I�d}����]Cߎ����k؂ٝ#4�	ǟ�s�gr����-�/���wJ/Yt�7\ru4��s�Ć˰Ht)���F.�O�_r�!�J�6�\roc�a�FОJ3\"p��0�M�}�14M�+	��y�7�T�.�&�x]�\\��t���;���9�θH��&\r�f`P/]�皅\0.���:-�F�qԞ]P��I�2�g�N7ӻr3\n0A<�T�V:ÛM��,z7�\"`�v��8\"ai�5��E\nS��\r��6@���D|�@?�<я�X��DA�N�\"�-݌O ��v�:�.)�H��=\"hh��s�>�T���vœs�F�ٝO׸\\�O�0&Q��P��\r\r�~�b���ȧ�Cp����X�����m�C���)����N��a��9���NO�\'P휒$E��AJq��z	�ċg���a�{9	�3)�9�a .�7��\Z�� ,0�4�8���\rL9��%�V�.��=���,c�,�?��Kw�3TZ/9���t�\"Jb�*t�Vv+I����\"���F-�!��[�2KK��T=9�Γ���3�c���ƭ�Z�*`�Q�*J�����NC��z	��,�j��E70b5�T�l�BÒ�L��^�$a���>Nr`�вf���k�;z4�Q0�YR%��[5�J!8�\\!9�$B��X�i@�����]	΁����df�M,k��д�a{�&gJ�$��t����2.ϩS�S��S�F��O�U�l�~���.�$ �ď�:�J[�zX�wU�#O���ȗ�o��3��(�+8�7��42�5uB���Qzt\Z�V������\0뚹&��?x��{p]�è۱�8��=������Ӎ��ij�Gŉ$�;��!��ב=έA��֧jG�N���j3�!�\r; ��!zӽO�XW&�ay�î����P���ޘ*	�����T)f%���/#�9�s��<\\��₌�v�:�B�6�I7�#\0��q�Պ��ͼ��s�k��49�`�d��O��D�\'�tu÷Jtd���ZhLs���v��\r�c;���@܂�b�����\0��:���p�*]�х��>��J̠W6�J�	� B�@�t��� US������*�p��S�MwCc�JW��y�I���y,?\r���,u,/R�B0��NY��袘�X��Fm��k�sc1�]](T��|.iSe\nR��a\'�X��\0n��u�&I��\rJ�[z;})1�2p���*��:d��E-�C�W����l��$�����U6�W��m�_(�\nP�֢dC�rW}��eIĲ4]�^�\\c<����iH�逷�����9���wk�F����lT=�T!��!�.NFvq�U�$�\Z���Lc��<���φ�0o�Zd�h�;Ԏl����v~v�Ϫ9��u(͑�Tj$���Z�(X׉I��,�*u�1_�22B£�l {恭���b�[�R%��gW��^�d�1�c�σ\n�����Q\'�Y{��>#�̢U�闱J��#�X�Ȇ���o$L+$s���+Ç��^H�����5*�E��+|d�+\r����T�����ʚ;���[���*SbQDc�u�����Ӳ`��\'�����\r����x_�c��(P��H�ӻ��A��\'![�胘�([���K��k�ZY۲��g�\">���J��\r���m��{���:0��#�q�?VEY0k�m\\�8]ê�T��VQ�\rhߨ�գjW�r�pd�	b�_ĩ�R8��]l�\n��\'9��Y;�o�\\�h�O9��xQ��m�V^���:;�bIGL����x|�R1�>It��>����5��:����XB��Q�*�{b�K�g[x���u�&�~Wg�j<��S*����t�+O��jl�H�j-�[����wZ����q�y�u_�0SA��}[��\"�����\n�q\"-\n��&\rXr�6ˢ��݋&\'R|! -�\'Cg� V�fj7����]o�8U��e^�2i�6߮����0����C}<��!⻺�C�>�[_�~��^�	� ��\'�\\(`GP\r���(<K���}���u�ѱ�1S��r;���)4�;\0���;�n�|\nq�B�U��R;��&^>�9W��V 3�Jg0�(�jQv�\Zھ�-�\'%��;w�&P��Pyz����ewT��܊���1)v�����n��$��8C,}��bث8O�M�[�|	_��`�D6lY���|�����n��g1�W�Ҭ���)&��6C�1d}Nk���2�l��*ef�d���n�T|W������!W�囲5��P���1����c�W���,�Wy!q8��S�ou}�f��k.����xs��8���1Ň�� �L�]�H�\0ƫ�U�\n0��X1�q��-�g��L�@�Ƃmh�ږ����l6����\0���5�XȒ�R�3�E�~-M!��T�g��L���gu�l�gYJ�2�+�e3lg���v�6E�����D�S\0��*�\"�3ݸYG%\'b�)��̭���~2WiyA�*h0��WZq�����b\Z�b�!#�K8[��ݺ��\Z���C�ݰ@f��z�n7)A@c?|Q\n�	z8�����S:�e��P�[�?gQ�Ƹ����:�{��3�A���,ۯ�������x��K���3���(�r`�tM$@D;��D��6�AZ�ނ&h#\\�Zj�!��B:�+m40:�}�:�XZw�|A����(��)���ׅ�Ôc�a�f�W^f�	�?�Z�Q�,R�VE6�Y2!:��7�/��RU2�}W���T��D�������c:�k���h^�^��fN���f��3��vWI����\Z�Zj�XK�IgAF]}�/`m�(�c7	3?r1�P]�:�!��nX\030^��F�D<b>	�;�,5��1���B�Tۍ~3��<\'�ɾ��x�k�m�:��������eN�pI5�s��CobJn��\n�/sj���2��KK�o&A�$c��)W58U�,����ʜ�[��,��$_��g�F&��y��L�W��G���f�m���\\DS�WH���.�ϵ5��]�:A�-\\�r֜�.��a���H���	C��0/�E��m��q6�/���3ֵ0��YV��9Ó5���:b~$��_;������:�+�afujg^�$�b�y�/z�y�v�ͶZ1=�\\2�޳��A��^�5�n_���	���~)������~����|�t�n��ny��Zݹ�;�2g�<~\"Gy��eN���y�4�V�]��/�ڗvr�����̥g�>>���>-��i�x}��l������&���:����-@V���X�wV~�>~OS�E�w��=���\ZU�@�I�]�9��G$�)�jP񪙌��-;u��KY������*��y�\'��I�`���1=kx�[]�ʜ�hTg��u)4�}�s ������i�_�� ��y�d_J�u��o4ޞ�����ۼR���?��@�*]��Ƒl8��~�3��އ����X?�k�������Q�����C7���e���r�I�;~�ך��čK�=[Q�����TLE,y���^���9��8������`ڳ�k�f���tm%\nG�`�y�������=v�^>�Q�{��G���/��m~f����/��,^>���q~�����=~��Ȋ��rc�l���*[�6��4��|�Ìå�!�>r _.y\'��������E��:�7�l$0o�����]��q��\r]n��ű�}hmWb	�}/�	�o�)�R���e�b�R�.�GCQ,�V`�\"��ӄ&x	CT��W�T�JMa��H����}��1~���6��&����_��v�4�*����^B�ycFB��]�����.�E��p��?�$�/�X��ϙ1dol�/��L�8a���\\-&��P�m:l\r�� h���\n|Jz�^\0On�63줡�``�\r������w�N��:��&���$��{$<�-�,9����!(k��D��N�*�7��<N�+5��R{�+�b�/9	,\Z��؟�2���k8�,�yC�\r��Y?��&���d��;!x��?���4c��,��s؟fUP���FJ\Z�\'	��F�t��f���tq������Ի.�V9lT������t�,m[�cA!~ 	��|C�?\"�Lam��<?�c���n���&<|gR�`��J��.�{^O�cf�M�n�Ðo��������?�i�=x����_�]�t��aq�w.���O�)�����$�iиW*�O�=�G�Y����\"og�5�v���	�~b�6V܃-���^\Z\Z>Y�|)ʺZ$/�?<k폎�LJZ�屺���+(N�\'o�H�ۛٻ`����`G��&X����T��J�Y���˗a[��{�i�[���U�|�q����\0��QV&��7��^�忻m�'),(20,'redirects_ca84d1343b96baa8137c943ed1860e522cacb238',1671288433,'x�K�2���\0O�'),(29,'1_33a584b3be12af15a5e16ac80ec5f0f09d6d3cf9',1671371636,'x��ko�8������S�-[�ǵ}hݤ�n�u�0hil�\"�Z���[��R�e�Q�w�-pFbK��p8$y���C�Nz^��0��Z���-$����x��i�Z=���ݧ��o�gla�xxԧ�t>� ��:�<\Z�0���4����Y�K��\Z;�a��8b�5��@��[Tna��L��~�Y�V0%���\\�˃|j�\Z�΄�e ���L�Bx���8�)\0&3H���\n���_�#OQmB��\'����\n#x�Y�����3Pl|˹Z�2�F,!�\Z�y�V��W���/�ա��J��5OO���L���������L�Z6$6�)@�Ј%:�JAiTs�ΤJ�A>k������t���:���Ts��VÁ9��\"�E����䱅����\'\\�Pi?������f\'��A�v��cht9�ȿ@.��������1T(.�x��4�\'\"TR˙�[8�F�����z�^��2�Ck�K���H�\"7j�{.�ﮖ�\Z�g��4�:�.���|)���F��*�N�����R�*��T�W\"2�A�+��˫2Ej:�1���(9�FW�̐�W3�rU��f�2�\'�=�t����=�f%����*�:O����y���ȩ��N5�B������r�$�6���lR�撁$�\\	��O\Z�v�\r�y؞ͺ���}�n5�A�l4ڳ�SG��5;��I��qz�\"�Ѵ8��xR��99BCb���٨N�V���S7���h�\Z\nǜOI��B���\ry*S�����ј��n��2Z�O$�LD���PÏ-��r.�dY4�}�dYb$��E�+���ؼ��T��}H�}��?�mE^��Vbʝf�-�Zpo_��b)b���.�J��1�Gd	+�\Z��<xR��N���������C�u��\"����p���������.:���I�4���%�E���<La�w������ߗ{���f5�O���^#9#^6.yw�>��\r�~]:�s#����D���&S��r3��}J�*g��\n�a>�]��T���U�3+�D�n���!��E�䩼���o�}������˭�����_�q�����Q_�۝��R�@#�6�Ͳ/�n��}�+�g�੧*wԻVY�妴��vLv_�L��)t�h��w-��cS����f�|w�r��@*|��9�f�T�u�{N��<,�>M<1���1{����f�ɻB�E�����\'�]�_:}X(]�e��9�V�������_�$�͢�CT\"uy��fyjӘ�¬��)n����$t�Qg�PAq��x��G�%����7�\n���)��90� ���O�}?�i�\r?��h�h�C��a�8:ޘᾘ- �fyl�h1g?`i����mK^y�!��=��|#�S��\r?tC�\'8�|Hk���/&Ә���ہ!=�\0yp�~�d��BC�����c�Ơ`�=$��N?��C���2���j�l��k��4�1��ƅ_�J�\r�X��6jtO�޿���}]��\Z�\n0�����Y,>�Z����M��Z����_Z���5͍�!�0���K��EAz��7�QX�L�wT��~�b]� �f�J��P���sY�XU��G��av�0�Z��`\'�ŗ�LP�c�~aR�OC���kb3���L��%���fT�X��֯�C��^8�?�X \r��JB��b�ӱsS�,�\'�o��K��Ou�b�����%\n!Yȉ|}�����أ=\\�-w]�m��L��9n?�%[N��Ц���s�oX�&�;K��m]c4=/��&7�{�{�~t�]�L�	Ҳ�橻����Zɥ����&\nB�\"j��!�:�w�\\|}a��r]\n����^�+�^���=O��o�ۗ{Z�;Y�oN�}���)�Ў���oU�{�t<����������B\'V5=<�(h�<��E���W�\"�F��\0	��3�p��ĝ�A���S9��fG��5�/���=�Kl-�Ε.����s���bQd��ti��d¥y�&\r�QXbKӢ�х���l�箷�\0����#hL��T��f�2�Ir\"�����U�\\���0��GpIv.b��G�5O!��Qp�|������2*躝��w(	�hD4n?��S����Ř�Ѻ��������;7�#�$���fȂ��\'�@j/\'���wg@a{o��\"o�|�C����b�rY���1]����Ȥ:\"���w��bFzղe&��9��=���>+>����mB�dnK��PrE��J�s����]Uߋ�[�q�3o�3h/!��)&#f���nmB�����ɩ�3\"��1��\0]�V�CÝgXaQ�e$肆gG�v�{����8��Ȋ)�F��:����aN-ߛ8>�&��#}���)�vi�v@\ZG���s�޺-PŪ\"\0w4)�=2M��e�R%��/��&��}E`6\nJ7�6��h���`I,��\r�5�/s�\rW���u?j5�%���RP�;�JW���q�A	F+Mir�#7��r��E�M�2�¢���R(\"� -(�*cD��|B�U!]ʭ�\\�<�H��F�#�n���z+#��n�]@h0�eWpE�Hc��Lv�y�*�\"�	�A%�	�B3����l�ȸ�Sj��$E�\'1,]I����<%��2����I�u��:.h��d%&��9-���-���p�=��\"�4I���+�'),(30,'11_8c8d3c62ba9a9069eb260f7a3f0a425fd48f5c50',1671371638,'x��ks�H���>��������N�uWp�Q�*j�\Z��4���]W�߯{Fal�ٽ�Kݩʖ�߯�y���?��h��lS��o� �XP,�a|���������?�ϼ��ғƐ^^��b�h~����4\Z���%S\Z��/̼�\'��f�k�\n�&�����@��[�na�Z��\Z���%��\ZfD��g.נ���:^��B�\\q��r�y\n���F��\n�-\r�1o�\0<���,T����}d�f�y�Xk�nQ(7���+`�i����7�eL-�/����F|!�j��՗���e��:���⋥����~3jG�\'�����;4Gs)�Z56$6K��S�,��+td-@iTs!�Re� �������p\0�)2����e�%�\"h4����0��E�#�#��-�G~0e\ZS����^�°�D��׉���!���^\\ ��lE�-��{�P\\��V\"ie<VR˹iY�w�M\n\'W�փ2�h�L��\Z|�j`8��|ȇ&�Z��ȿk�����˳|�,ϑq6�d�����͑�\03R�h��������:��Ԉ�<1�Q�(4��uUM�F�%g����q�z.�T�kԹT�~����:]�0�I6kn�A�TR��E�1u�G�r��L�8�p\"5ЌY�v�\'���)m�S�K\0�)[E�<(�$�:8j�ݸ��;����{���gQ���y�k!�_�^��?l�^	ghZ�RI<����8FCRv/�QE�~��S7��5h�A�c���@�{jjc&��X7���Ly\\��dr����<��|��BY>�u^ʅ�h[�2<�J�oYR$�O�2Wl�b�y������ȷy�V[��9��.�Zp�n��,Eʽ8� ���R�l��Y���-�����y1��c��G�ׅ�>��7?H��=��k\Z���/wp��v��XNb�q�r/-��.Z��×���/�����$�G����f�M]�h��^#�G�ޤ�}��}�?�\r����b΍�o�k����GS\n��r3���$��j�\Z��|*��DK����\n�Y�gBw���r�_�I������#�\"����=�r+e�~��a��*Ϩ����n�\ZC\r�R&k�p/�H����mڪ��6�\\l�n<m��c��UViu2��c;&��L�]��=���g�7��\"5�iMZ̦9K��97ۏ�÷Π���|9=\0�F=��-������N�N?��OA$G��pH��\\�ɝX��<�b<�R�r�z8xD�p����č?\Z�opV�<�P�j�à�j[��񴊿�,��5���[�M���/;�0<o8�=e�\'�WHt��x4��0M�a�6��N�g/��|A�������ٵ�+��]�%(���R%��%���±M�����ױT�������~���2|\r�������	ȚX9y����3�����oUv�������;�j���������yEQg��T���S�\Z]Dը;��`�?��\Z�~g}DPa$}�f!�6i6��m�HR�k�x��+S�Ćv��s���cQd��ti��i2�R���T�K�(����P��n�	��sw�D���f�	4�M\"c�%�J�k�$9�+x�:�I��+�4&�D7���<�~�$�f�:\'0+;ዪ����II����GE(�1Ѹ�i\'��d����>�Ѻw�`2>ᚚ���XfYyݻIY4p�W�L��Q����(�ҽl;4Eް�.S�.7jZ;����p鏐�~���Ȥ>\"3��?���[�X�:����]�{�w��|Ȋ�z?c\Z�]��U�mA�spK&�4ݮ�9�u��.�������v�1�\'�Z�+H�z�Ɉ��ł�a�\"��s���c[�݋ףC�.r차c�]Pzv4ah��L����C�����8U��2����a!�����5�C����N��t+��p��1Ðl$�K��K�fU�;��o�����2v]���o�6�� _Fe#��9�sٖu+)\r6C(s�m���a�����kgE��q�Y���-շ�u\r\ZVP��*0��T�b��1]��Ӈ��l���\"�j l7n{X	E��\'	�\n��P�2�g�G���SUMJyM:u3�\"���˃��D޺T��P\Z\'�~��ؑ�h�r�E�.�������矙�BO�NeZ���g��.S�OSX�fnU�F��s\Z���ߞ�M���g������f@��`l�?|���&����J�޷*9OTB�ϩ�U���+�z�;\n;Ga��w�6�,�0Q�Y�q����e���M�p��g�2ldJ	�&��f2�tC��t��d\Z�d׿\0���');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES (15,'2_2bfb73cda7b72fbc3cd3b9eb52e99367e6fb8406','pageId_2'),(33,'1_33a584b3be12af15a5e16ac80ec5f0f09d6d3cf9','pageId_1'),(34,'11_8c8d3c62ba9a9069eb260f7a3f0a425fd48f5c50','tx_news'),(35,'11_8c8d3c62ba9a9069eb260f7a3f0a425fd48f5c50','tx_news_domain_model_news'),(36,'11_8c8d3c62ba9a9069eb260f7a3f0a425fd48f5c50','pageId_11');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection`
--

DROP TABLE IF EXISTS `cache_pagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection`
--

LOCK TABLES `cache_pagesection` WRITE;
/*!40000 ALTER TABLE `cache_pagesection` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pagesection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection_tags`
--

DROP TABLE IF EXISTS `cache_pagesection_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection_tags`
--

LOCK TABLES `cache_pagesection_tags` WRITE;
/*!40000 ALTER TABLE `cache_pagesection_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pagesection_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES (156,'1__0_0_1',1673876994,'a:1:{i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(157,'1__0_0_0',1673877015,'a:1:{i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(158,'2__0_0_0',1673877015,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:2;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:6:\"Search\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(159,'3__0_0_0',1673877015,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:3;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:5:\"Login\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(160,'11__0_0_0',1673877015,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:11;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:4:\"News\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:55:\"EXT:news/Configuration/TSconfig/Page/news_only.tsconfig\";s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(161,'7__0_0_0',1673877015,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(162,'8__0_0_0',1673877015,'a:3:{i:2;a:21:{s:3:\"pid\";i:7;s:3:\"uid\";i:8;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:11:\"Subpage One\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(163,'9__0_0_0',1673877015,'a:3:{i:2;a:21:{s:3:\"pid\";i:7;s:3:\"uid\";i:9;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:11:\"Subpage Two\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(164,'10__0_0_0',1673877015,'a:3:{i:2;a:21:{s:3:\"pid\";i:7;s:3:\"uid\";i:10;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:13:\"Subpage Three\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(165,'5__0_0_0',1673877015,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:5;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:22:\"Access Restricted Page\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:2:\"-2\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(166,'2__0_0_1',1673877911,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:2;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:6:\"Search\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(167,'3__0_0_1',1673877911,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:3;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:5:\"Login\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(168,'11__0_0_1',1673877911,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:11;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:4:\"News\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:55:\"EXT:news/Configuration/TSconfig/Page/news_only.tsconfig\";s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(169,'7__0_0_1',1673877911,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(170,'8__0_0_1',1673877911,'a:3:{i:2;a:21:{s:3:\"pid\";i:7;s:3:\"uid\";i:8;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:11:\"Subpage One\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(171,'9__0_0_1',1673877911,'a:3:{i:2;a:21:{s:3:\"pid\";i:7;s:3:\"uid\";i:9;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:11:\"Subpage Two\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(172,'10__0_0_1',1673877911,'a:3:{i:2;a:21:{s:3:\"pid\";i:7;s:3:\"uid\";i:10;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:13:\"Subpage Three\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:7;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:18:\"Page with Subpages\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}'),(173,'5__0_0_1',1673877911,'a:2:{i:1;a:21:{s:3:\"pid\";i:1;s:3:\"uid\";i:5;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:22:\"Access Restricted Page\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:2:\"-2\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";N;s:11:\"is_siteroot\";i:0;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}i:0;a:21:{s:3:\"pid\";i:0;s:3:\"uid\";i:1;s:9:\"t3ver_oid\";i:0;s:10:\"t3ver_wsid\";i:0;s:11:\"t3ver_state\";i:0;s:5:\"title\";s:7:\"Welcome\";s:9:\"nav_title\";s:0:\"\";s:5:\"media\";s:0:\"\";s:6:\"layout\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:7:\"doktype\";i:1;s:8:\"TSconfig\";N;s:17:\"tsconfig_includes\";s:0:\"\";s:11:\"is_siteroot\";i:1;s:9:\"mount_pid\";i:0;s:12:\"mount_pid_ol\";i:0;s:25:\"backend_layout_next_level\";s:0:\"\";}}');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=372 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES (332,'1__0_0_1','pageId_1'),(333,'1__0_0_0','pageId_1'),(334,'2__0_0_0','pageId_2'),(335,'2__0_0_0','pageId_1'),(336,'3__0_0_0','pageId_3'),(337,'3__0_0_0','pageId_1'),(338,'11__0_0_0','pageId_11'),(339,'11__0_0_0','pageId_1'),(340,'7__0_0_0','pageId_7'),(341,'7__0_0_0','pageId_1'),(342,'8__0_0_0','pageId_8'),(343,'8__0_0_0','pageId_7'),(344,'8__0_0_0','pageId_1'),(345,'9__0_0_0','pageId_9'),(346,'9__0_0_0','pageId_7'),(347,'9__0_0_0','pageId_1'),(348,'10__0_0_0','pageId_10'),(349,'10__0_0_0','pageId_7'),(350,'10__0_0_0','pageId_1'),(351,'5__0_0_0','pageId_5'),(352,'5__0_0_0','pageId_1'),(353,'2__0_0_1','pageId_2'),(354,'2__0_0_1','pageId_1'),(355,'3__0_0_1','pageId_3'),(356,'3__0_0_1','pageId_1'),(357,'11__0_0_1','pageId_11'),(358,'11__0_0_1','pageId_1'),(359,'7__0_0_1','pageId_7'),(360,'7__0_0_1','pageId_1'),(361,'8__0_0_1','pageId_8'),(362,'8__0_0_1','pageId_7'),(363,'8__0_0_1','pageId_1'),(364,'9__0_0_1','pageId_9'),(365,'9__0_0_1','pageId_7'),(366,'9__0_0_1','pageId_1'),(367,'10__0_0_1','pageId_10'),(368,'10__0_0_1','pageId_7'),(369,'10__0_0_1','pageId_1'),(370,'5__0_0_1','pageId_5'),(371,'5__0_0_1','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_workspaces_cache`
--

DROP TABLE IF EXISTS `cache_workspaces_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_workspaces_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_workspaces_cache`
--

LOCK TABLES `cache_workspaces_cache` WRITE;
/*!40000 ALTER TABLE `cache_workspaces_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_workspaces_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_workspaces_cache_tags`
--

DROP TABLE IF EXISTS `cache_workspaces_cache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_workspaces_cache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_workspaces_cache_tags`
--

LOCK TABLES `cache_workspaces_cache_tags` WRITE;
/*!40000 ALTER TABLE `cache_workspaces_cache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_workspaces_cache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
INSERT INTO `fe_groups` VALUES (1,4,1668274317,1668274317,3,0,0,'','0','Website','','','');
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `usergroup` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
INSERT INTO `fe_users` VALUES (1,4,1668274337,1668274337,3,0,0,0,0,'','0','admin','$argon2i$v=19$m=65536,t=16,p=1$TVVVenpqVU1HQ1Z5ZEJBbA$nycID6/fNzHFsupxC+OokvgqOJNaXWeAnzpgs0QA8fw','1','','','','','','','','',NULL,'','','','','','',NULL,'',1668274346,1668274408,NULL,'','');
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_config`
--

DROP TABLE IF EXISTS `index_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_config` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `set_id` int(11) NOT NULL DEFAULT 0,
  `session_data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `depth` int(10) unsigned NOT NULL DEFAULT 0,
  `table2index` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alternative_source_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `get_params` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fieldlist` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `externalUrl` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `indexcfgs` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filepath` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extensions` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `timer_next_indexing` int(11) NOT NULL DEFAULT 0,
  `timer_frequency` int(11) NOT NULL DEFAULT 0,
  `timer_offset` int(11) NOT NULL DEFAULT 0,
  `url_deny` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recordsbatch` int(11) NOT NULL DEFAULT 0,
  `records_indexonchange` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_config`
--

LOCK TABLES `index_config` WRITE;
/*!40000 ALTER TABLE `index_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_debug`
--

DROP TABLE IF EXISTS `index_debug`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_debug` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `debuginfo` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_debug`
--

LOCK TABLES `index_debug` WRITE;
/*!40000 ALTER TABLE `index_debug` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_debug` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_fulltext`
--

DROP TABLE IF EXISTS `index_fulltext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_fulltext` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `fulltextdata` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaphonedata` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_fulltext`
--

LOCK TABLES `index_fulltext` WRITE;
/*!40000 ALTER TABLE `index_fulltext` DISABLE KEYS */;
INSERT INTO `index_fulltext` VALUES (3380386,'Subpage Three   TYPO3 Crawler Devbox   \n     \n     \n         \n            \n                 \n                     \n                        Home\n                     \n                    \n                 \n            \n                 \n                     \n                        Search\n                     \n                    \n                 \n            \n                 \n                     \n                        Login\n                     \n                    \n                 \n            \n                 \n                     \n                        News\n                     \n                    \n                 \n            \n                 \n                     \n                        Page with Subpages\n                     \n                    \n                         \n                            \n                                 \n                                     \n                                        Subpage One\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Two\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Three',''),(33280944,'Subpage One   TYPO3 Crawler Devbox   \n     \n     \n         \n            \n                 \n                     \n                        Home\n                     \n                    \n                 \n            \n                 \n                     \n                        Search\n                     \n                    \n                 \n            \n                 \n                     \n                        Login\n                     \n                    \n                 \n            \n                 \n                     \n                        News\n                     \n                    \n                 \n            \n                 \n                     \n                        Page with Subpages\n                     \n                    \n                         \n                            \n                                 \n                                     \n                                        Subpage One\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Two\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Three',''),(64460995,'Welcome   TYPO3 Crawler Devbox   \n     \n     \n         \n            \n                 \n                     \n                        Home\n                     \n                    \n                 \n            \n                 \n                     \n                        Search\n                     \n                    \n                 \n            \n                 \n                     \n                        Login\n                     \n                    \n                 \n            \n                 \n                     \n                        News\n                     \n                    \n                 \n            \n                 \n                     \n                        Page with Subpages\n                     \n                    \n                         \n                            \n                                 \n                                     \n                                        Subpage One\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Two\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Three\n                                     \n                                 \n                            \n                         \n                    \n                 \n            \n         \n     \n \n \n\n \n     \n         \n             \n            \n    \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n         \n            \n\n    \n            \n                \n\n    \n             \n                Welcome - This is the TYPO3 Crawler Devbox\n             \n        \n\n\n\n            \n        \n\n\n\n            \n\n\n\n            \n\n\n\n         \n    \n\n\n\n                \n                \n\n     The devbox has close to zero frontend, as most of the functionality is backend related. If there are content examples missing, please create an issue on GitHub. \n Here are some links that you might find helpful.   	 Docs:  https://docs.typo3.org/p/tomasnorre/crawler/main/en-us/   	 Issues:  https://github.com/tomasnorre/crawler/issues   	 Repository:  https://github.com/tomasnorre/crawler/   	 Slack:  typo3.slack.com/archives/C087NGBKM    \n\n\n                \n                    \n\n\n\n                \n                \n                    \n\n\n\n                \n             \n\n        \n\n\n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                \n\n     Try it',''),(91021701,'Search   TYPO3 Crawler Devbox   \n     \n     \n         \n            \n                 \n                     \n                        Home\n                     \n                    \n                 \n            \n                 \n                     \n                        Search\n                     \n                    \n                 \n            \n                 \n                     \n                        Login\n                     \n                    \n                 \n            \n                 \n                     \n                        News\n                     \n                    \n                 \n            \n                 \n                     \n                        Page with Subpages\n                     \n                    \n                         \n                            \n                                 \n                                     \n                                        Subpage One\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Two\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Three\n                                     \n                                 \n                            \n                         \n                    \n                 \n            \n         \n     \n \n \n\n \n     \n         \n             \n            \n    \n    \n\n             \n                \n                \n                    \n\n\n\n                \n                \n                    \n\n    \n         \n            \n\n    \n            \n                \n\n    \n             \n                Search',''),(167292954,'News   TYPO3 Crawler Devbox   \n     \n     \n         \n            \n                 \n                     \n                        Home\n                     \n                    \n                 \n            \n                 \n                     \n                        Search\n                     \n                    \n                 \n            \n                 \n                     \n                        Login\n                     \n                    \n                 \n            \n                 \n                     \n                        News\n                     \n                    \n                 \n            \n                 \n                     \n                        Page with Subpages\n                     \n                    \n                         \n                            \n                                 \n                                     \n                                        Subpage One\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Two\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Three',''),(177091504,'Subpage Two   TYPO3 Crawler Devbox   \n     \n     \n         \n            \n                 \n                     \n                        Home\n                     \n                    \n                 \n            \n                 \n                     \n                        Search\n                     \n                    \n                 \n            \n                 \n                     \n                        Login\n                     \n                    \n                 \n            \n                 \n                     \n                        News\n                     \n                    \n                 \n            \n                 \n                     \n                        Page with Subpages\n                     \n                    \n                         \n                            \n                                 \n                                     \n                                        Subpage One\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Two\n                                     \n                                 \n                            \n                                 \n                                     \n                                        Subpage Three','');
/*!40000 ALTER TABLE `index_fulltext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_grlist`
--

DROP TABLE IF EXISTS `index_grlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_grlist` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` int(11) NOT NULL DEFAULT 0,
  `phash_x` int(11) NOT NULL DEFAULT 0,
  `hash_gr_list` int(11) NOT NULL DEFAULT 0,
  `gr_list` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`hash_gr_list`),
  KEY `phash_grouping` (`phash_x`,`hash_gr_list`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_grlist`
--

LOCK TABLES `index_grlist` WRITE;
/*!40000 ALTER TABLE `index_grlist` DISABLE KEYS */;
INSERT INTO `index_grlist` VALUES (42,33280944,33280944,215747215,'0,-1'),(43,177091504,177091504,215747215,'0,-1'),(44,3380386,3380386,215747215,'0,-1'),(51,167292954,167292954,215747215,'0,-1'),(54,91021701,91021701,215747215,'0,-1'),(57,64460995,64460995,215747215,'0,-1');
/*!40000 ALTER TABLE `index_grlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_phash`
--

DROP TABLE IF EXISTS `index_phash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_phash` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `phash_grouping` int(11) NOT NULL DEFAULT 0,
  `static_page_arguments` blob DEFAULT NULL,
  `data_filename` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `data_page_id` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_type` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_mp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gr_list` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `item_type` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `item_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `item_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `item_mtime` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `item_size` int(11) NOT NULL DEFAULT 0,
  `contentHash` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `parsetime` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `item_crdate` int(11) NOT NULL DEFAULT 0,
  `externalUrl` smallint(6) NOT NULL DEFAULT 0,
  `recordUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexSetId` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`),
  KEY `phash_grouping` (`phash_grouping`),
  KEY `freeIndexUid` (`freeIndexUid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_phash`
--

LOCK TABLES `index_phash` WRITE;
/*!40000 ALTER TABLE `index_phash` DISABLE KEYS */;
INSERT INTO `index_phash` VALUES (3380386,37882121,'[]','',10,0,'','0,-1','0','Subpage Three','TYPO3 Crawler Devbox Home Search Login News Page with Subpages Subpage One Subpage Two Subpage Three',1668277434,1668277880,4248,77772496,1668277880,6,0,1668274736,0,0,0,0),(33280944,32244978,'[]','',8,0,'','0,-1','0','Subpage One','TYPO3 Crawler Devbox Home Search Login News Page with Subpages Subpage One Subpage Two Subpage Three',1668277420,1668277879,4242,143487019,1668277879,8,0,1668274689,0,0,0,0),(64460995,231284643,'[]','',1,0,'','0,-1','0','Welcome','TYPO3 Crawler Devbox Home Search Login News Page with Subpages Subpage One Subpage Two Subpage Three Welcome - This is the TYPO3 Crawler Devbox The devbox has close to zero frontend, as most of the fu',1668277760,1671285015,6333,126954612,1671285015,15,0,1668273256,0,0,0,0),(91021701,212719941,'[]','',2,0,'','0,-1','0','Search','TYPO3 Crawler Devbox Home Search Login News Page with Subpages Subpage One Subpage Two Subpage Three Search',1668273773,1671284589,4677,9436543,1671284589,7,0,1668273714,0,0,0,0),(167292954,39855917,'[]','',11,0,'','0,-1','0','News','TYPO3 Crawler Devbox Home Search Login News Page with Subpages Subpage One Subpage Two Subpage Three',1668755434,1671267728,4690,157738715,1671267728,8,0,1668275672,0,0,0,0),(177091504,39610013,'[]','',9,0,'','0,-1','0','Subpage Two','TYPO3 Crawler Devbox Home Search Login News Page with Subpages Subpage One Subpage Two Subpage Three',1668277427,1668277880,4242,96042353,1668277880,7,0,1668274698,0,0,0,0);
/*!40000 ALTER TABLE `index_phash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_rel`
--

DROP TABLE IF EXISTS `index_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_rel` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `wid` int(11) NOT NULL DEFAULT 0,
  `count` smallint(5) unsigned NOT NULL DEFAULT 0,
  `first` int(10) unsigned NOT NULL DEFAULT 0,
  `freq` smallint(5) unsigned NOT NULL DEFAULT 0,
  `flags` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`,`wid`),
  KEY `wid` (`wid`,`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_rel`
--

LOCK TABLES `index_rel` WRITE;
/*!40000 ALTER TABLE `index_rel` DISABLE KEYS */;
INSERT INTO `index_rel` VALUES (3380386,6984764,1,4,17777,0),(3380386,17213122,1,3,17777,0),(3380386,37378239,1,8,17777,0),(3380386,45876342,1,9,17777,0),(3380386,56454451,2,0,32000,128),(3380386,84461404,1,6,17777,0),(3380386,119038151,1,7,17777,0),(3380386,162981937,4,0,32000,128),(3380386,193634161,1,13,17777,0),(3380386,215402742,1,1,17777,0),(3380386,223786649,1,5,17777,0),(3380386,230758345,1,0,17777,0),(3380386,261604818,1,11,17777,0),(3380386,262520194,1,2,17777,0),(33280944,6984764,1,4,17777,0),(33280944,17213122,1,3,17777,0),(33280944,37378239,1,8,17777,0),(33280944,45876342,1,9,17777,0),(33280944,56454451,1,15,17777,0),(33280944,84461404,1,6,17777,0),(33280944,119038151,1,7,17777,0),(33280944,162981937,4,0,32000,128),(33280944,193634161,1,13,17777,0),(33280944,215402742,1,1,17777,0),(33280944,223786649,1,5,17777,0),(33280944,230758345,1,0,17777,0),(33280944,261604818,2,0,32000,128),(33280944,262520194,1,2,17777,0),(64460995,1797664,1,27,4571,0),(64460995,4020710,1,52,4571,0),(64460995,6984764,1,4,4571,0),(64460995,8451665,1,67,4571,0),(64460995,11199688,1,47,4571,0),(64460995,13715897,1,68,4571,0),(64460995,17213122,1,3,4571,0),(64460995,25887900,1,46,4571,0),(64460995,34964166,1,54,4571,0),(64460995,37378239,1,8,4571,0),(64460995,45876342,1,9,4571,0),(64460995,53516922,1,25,4571,0),(64460995,56454451,1,15,4571,0),(64460995,60590402,1,38,4571,0),(64460995,67198620,2,40,9142,0),(64460995,67888357,2,0,9142,128),(64460995,84461404,1,6,4571,0),(64460995,96048944,1,66,4571,0),(64460995,100994278,1,44,4571,0),(64460995,103295597,1,60,4571,0),(64460995,104446697,1,55,4571,0),(64460995,113844869,1,50,4571,0),(64460995,118945459,1,26,4571,0),(64460995,119038151,1,7,4571,0),(64460995,121436318,1,64,4571,0),(64460995,124690622,1,45,4571,0),(64460995,134706771,1,53,4571,0),(64460995,146770004,1,32,4571,0),(64460995,150749894,3,19,13714,0),(64460995,151966801,1,37,4571,0),(64460995,161494603,1,41,4571,0),(64460995,162981937,3,10,13714,0),(64460995,166274537,1,17,4571,0),(64460995,170546458,2,18,9142,0),(64460995,172512000,1,62,4571,0),(64460995,181023673,1,29,4571,0),(64460995,181963483,1,56,4571,0),(64460995,188686389,1,63,4571,0),(64460995,189005273,1,36,4571,0),(64460995,193634161,1,13,4571,0),(64460995,200414488,1,49,4571,0),(64460995,201244212,1,42,4571,0),(64460995,202738483,1,58,4571,0),(64460995,203752250,1,65,4571,0),(64460995,215402742,2,1,9142,0),(64460995,218285252,1,28,4571,0),(64460995,223786649,1,5,4571,0),(64460995,226823940,1,39,4571,0),(64460995,230758345,2,0,9142,0),(64460995,238955163,1,59,4571,0),(64460995,245461218,1,57,4571,0),(64460995,245504065,1,43,4571,0),(64460995,248690112,1,48,4571,0),(64460995,256253357,1,34,4571,0),(64460995,259787273,1,31,4571,0),(64460995,261557799,1,30,4571,0),(64460995,261604818,1,11,4571,0),(64460995,262520194,3,2,13714,0),(64460995,266731012,1,61,4571,0),(91021701,6984764,3,0,32000,128),(91021701,17213122,1,3,17777,0),(91021701,37378239,1,8,17777,0),(91021701,45876342,1,9,17777,0),(91021701,56454451,1,15,17777,0),(91021701,84461404,1,6,17777,0),(91021701,119038151,1,7,17777,0),(91021701,162981937,3,10,32000,0),(91021701,193634161,1,13,17777,0),(91021701,215402742,1,1,17777,0),(91021701,223786649,1,5,17777,0),(91021701,230758345,1,0,17777,0),(91021701,261604818,1,11,17777,0),(91021701,262520194,1,2,17777,0),(167292954,6984764,1,4,18823,0),(167292954,17213122,1,3,18823,0),(167292954,37378239,1,8,18823,0),(167292954,45876342,1,9,18823,0),(167292954,56454451,1,15,18823,0),(167292954,84461404,2,0,32000,128),(167292954,119038151,1,7,18823,0),(167292954,162981937,3,10,32000,0),(167292954,193634161,1,13,18823,0),(167292954,215402742,1,1,18823,0),(167292954,223786649,1,5,18823,0),(167292954,230758345,1,0,18823,0),(167292954,261604818,1,11,18823,0),(167292954,262520194,1,2,18823,0),(177091504,6984764,1,4,17777,0),(177091504,17213122,1,3,17777,0),(177091504,37378239,1,8,17777,0),(177091504,45876342,1,9,17777,0),(177091504,56454451,1,15,17777,0),(177091504,84461404,1,6,17777,0),(177091504,119038151,1,7,17777,0),(177091504,162981937,4,0,32000,128),(177091504,193634161,2,0,32000,128),(177091504,215402742,1,1,17777,0),(177091504,223786649,1,5,17777,0),(177091504,230758345,1,0,17777,0),(177091504,261604818,1,11,17777,0),(177091504,262520194,1,2,17777,0);
/*!40000 ALTER TABLE `index_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_section`
--

DROP TABLE IF EXISTS `index_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_section` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` int(11) NOT NULL DEFAULT 0,
  `phash_t3` int(11) NOT NULL DEFAULT 0,
  `rl0` int(10) unsigned NOT NULL DEFAULT 0,
  `rl1` int(10) unsigned NOT NULL DEFAULT 0,
  `rl2` int(10) unsigned NOT NULL DEFAULT 0,
  `page_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`rl0`),
  KEY `page_id` (`page_id`),
  KEY `rl0` (`rl0`,`rl1`,`phash`),
  KEY `rl0_2` (`rl0`,`phash`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_section`
--

LOCK TABLES `index_section` WRITE;
/*!40000 ALTER TABLE `index_section` DISABLE KEYS */;
INSERT INTO `index_section` VALUES (41,33280944,33280944,1,7,8,8),(42,177091504,177091504,1,7,9,9),(43,3380386,3380386,1,7,10,10),(50,167292954,167292954,1,11,0,11),(53,91021701,91021701,1,2,0,2),(56,64460995,64460995,1,0,0,1);
/*!40000 ALTER TABLE `index_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_stat_word`
--

DROP TABLE IF EXISTS `index_stat_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_stat_word` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `index_stat_search_id` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `pageid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tstamp` (`tstamp`,`word`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_stat_word`
--

LOCK TABLES `index_stat_word` WRITE;
/*!40000 ALTER TABLE `index_stat_word` DISABLE KEYS */;
INSERT INTO `index_stat_word` VALUES (1,'tomas',0,1668274189,2),(2,'links',0,1668274193,2),(3,'frontend',0,1668274552,2);
/*!40000 ALTER TABLE `index_stat_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_words`
--

DROP TABLE IF EXISTS `index_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_words` (
  `wid` int(11) NOT NULL DEFAULT 0,
  `baseword` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `metaphone` int(11) NOT NULL DEFAULT 0,
  `is_stopword` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`wid`),
  KEY `baseword` (`baseword`),
  KEY `metaphone` (`metaphone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_words`
--

LOCK TABLES `index_words` WRITE;
/*!40000 ALTER TABLE `index_words` DISABLE KEYS */;
INSERT INTO `index_words` VALUES (1797664,'to',194956824,0),(4020710,'some',81843446,0),(6984764,'search',258598115,0),(8451665,'try',247333392,0),(11199688,'issue',12566892,0),(12207161,'check',55777169,0),(13715897,'it',215163142,0),(17213122,'home',57283239,0),(25887900,'an',227967440,0),(34964166,'that',27300898,0),(35272221,'push',142502919,0),(37378239,'with',216420469,0),(45876342,'subpages',245242303,0),(53516922,'has',89785684,0),(56454451,'three',40763120,0),(60590402,'if',233238059,0),(67198620,'are',95820315,0),(67888357,'welcome',70773243,0),(74248421,'visible',137138802,0),(84461404,'news',87854357,0),(90118488,'should',178878401,0),(96048944,'typo3.slack.com/archives/c087ngbkm',5801780,0),(100994278,'please',110621615,0),(103295597,'https://docs.typo3.org/p/tomasnorre/crawler/main/en-us',181245322,0),(104446697,'you',92073025,0),(113844869,'here',265602616,0),(118945459,'close',69848713,0),(119038151,'page',11939573,0),(121436318,'https://github.com/tomasnorre/crawler',156887224,0),(124690622,'create',156564137,0),(133151086,'indexed',72987633,0),(134706771,'links',169077174,0),(146770004,'of',132387706,0),(150749894,'the',217895432,0),(151966801,'related',113702027,0),(152081754,'be',165014887,0),(161494603,'content',114119944,0),(162981937,'subpage',123504100,0),(165624577,'access',127141009,0),(166274537,'this',118069971,0),(170179826,'plugin',172529504,0),(170546458,'is',12566892,0),(172512000,'https://github.com/tomasnorre/crawler/issues',127717394,0),(179857950,'me',110531015,0),(181023673,'frontend',199599298,0),(181963483,'might',27901216,0),(188686389,'repository',169033510,0),(189005273,'backend',231061061,0),(193634161,'two',64591703,0),(200414488,'github',96390204,0),(201244212,'examples',209329087,0),(202738483,'helpful',177754666,0),(203752250,'slack',27580981,0),(210350911,'restricted',242145798,0),(212285643,'typoscript',145982040,0),(213246208,'error',215100333,0),(213374029,'in.',210169357,0),(215402742,'crawler',104398345,0),(218285252,'zero',147529744,0),(223518356,'not',213158643,0),(223700632,'for',18542032,0),(223786649,'login',242828301,0),(224955468,'logged',179206221,0),(226823940,'there',40763120,0),(230758345,'typo3',10755885,0),(238747114,'included.',177148377,0),(238955163,'docs',69306018,0),(245461218,'find',211521030,0),(245504065,'missing',34238002,0),(248690112,'on',151409131,0),(256253357,'functionality',243718161,0),(259787273,'most',162940566,0),(261557799,'as',170666265,0),(261604818,'one',151409131,0),(262520194,'devbox',129217954,0),(266731012,'issues',198556556,0);
/*!40000 ALTER TABLE `index_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1668277760,1668273256,3,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Welcome','/',1,NULL,1,0,'',6,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668277760,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(2,1,1668273773,1668273714,3,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Search','/search',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668273773,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(3,1,1668273765,1668273726,3,0,0,0,0,'',512,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Login','/login',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668273765,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(4,1,1668273750,1668273741,3,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"hidden\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Frontend Users','/frontend-users',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(5,1,1668274378,1668274364,3,0,0,0,0,'-2',640,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Access Restricted Page','/access-restricted-page',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668274378,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(6,1,1668277782,1668274428,3,0,0,0,0,'',128,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"shortcut_mode\":\"\",\"shortcut\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"target\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Home','/home',4,NULL,0,0,'',1,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668274478,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(7,1,1668277411,1668274630,3,0,0,0,0,'',576,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Page with Subpages','/page-with-subpages',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668277411,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(8,7,1668277420,1668274689,3,0,0,0,0,'',448,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Subpage One','/page-with-subpages/subpage-one',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668277420,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(9,7,1668277427,1668274698,3,0,0,0,0,'',512,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Subpage Two','/page-with-subpages/subpage-two',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668277427,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0),(10,7,1668277434,1668274736,3,0,0,0,0,'',768,'',0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'Subpage Three','/page-with-subpages/subpage-three',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1668277434,'','',0,'','','',0,0,0,0,0,0,'','','',0,'',0,0,'','',0,'','',0,'summary','',0.5,'',0),(11,1,1668755434,1668275672,3,0,0,0,0,'',544,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,3,0,31,27,0,'News','/news',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1668755434,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:news/Configuration/TSconfig/Page/news_only.tsconfig',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `arguments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `import_source` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `seo_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_headline` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `seo_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1668274532,0,0,0,'2',0,'/typo3/sysext/indexed_search/Resources/Public/Icons/FileTypes/pages.gif','a29edd12d132bfd31b97ef46f7cfb6aa74a967f4','1d50fb38753b56d6a38d6f0aae9ffc7db62efede','gif','image/gif','pages.gif','5c5fd7567caa18c3c6cff78996c73b78c2b77864',102,1668274006,1667909629);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `visible` int(10) unsigned DEFAULT 1,
  `status` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creator_tool` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `download_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `creator` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `publisher` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `copyright` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_country` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_region` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location_city` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `latitude` decimal(24,14) DEFAULT 0.00000000000000,
  `longitude` decimal(24,14) DEFAULT 0.00000000000000,
  `ranking` int(10) unsigned DEFAULT 0,
  `content_creation_date` int(10) unsigned DEFAULT 0,
  `content_modification_date` int(10) unsigned DEFAULT 0,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `duration` double DEFAULT 0,
  `color_space` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `pages` int(10) unsigned DEFAULT 0,
  `language` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `fe_groups` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1668274532,1668274532,3,0,0,NULL,0,'',0,0,0,0,1,NULL,18,16,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processing_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1668274532,1668274532,0,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','5c5fd7567caa18c3c6cff78996c73b78c2b77864','Image.CropScaleMask','0ca5f4f8c2',18,16);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1668273236,1668273236,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1668273241,2,'BE',3,0,2,'be_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$S05JSWtRbTVoeVYxeTUxVA$\\/Y2X3Zn7aivhUP2o6ktI+MhQgwD1G2qHpM6IsYeOo0I\"},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$N2t4NGhVcFkzUmV3T3BucA$wiWp9d8o2V6GZ8f6uSBDlnzZlUrU9nYGG73V2GxX\\/Rw\"}}',0,'0400$6321ea834f77ba99b88a0906c5f387c2:c98a59192960d7c1b8e415cda9ffe933'),(2,1668273256,1,'BE',3,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1668273256,\"crdate\":1668273256,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Welcome\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$2c19baf5442258c5892d72442e76e874:e175f7045d7ccbfb26ffcf279422c2e5'),(3,1668273286,2,'BE',3,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"tsconfig_includes\":null,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"is_siteroot\":\"1\",\"tsconfig_includes\":\"EXT:crawler_devbox_sitepackage\\/Configuration\\/TsConfig\\/Page\\/All.tsconfig\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$e8fa535c3d679ade82957f4efe92a52f:e175f7045d7ccbfb26ffcf279422c2e5'),(4,1668273292,2,'BE',3,0,1,'pages','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$14a243c2f8005cddf6d92b2567e5c648:e175f7045d7ccbfb26ffcf279422c2e5'),(5,1668273662,2,'BE',3,0,1,'pages','{\"oldRecord\":{\"tsconfig_includes\":\"EXT:crawler_devbox_sitepackage\\/Configuration\\/TsConfig\\/Page\\/All.tsconfig\"},\"newRecord\":{\"tsconfig_includes\":\"\"}}',0,'0400$a7c5d5e4e6445429d6e97da2fd1ca375:e175f7045d7ccbfb26ffcf279422c2e5'),(6,1668273666,1,'BE',3,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1668273666,\"crdate\":1668273666,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"NEW SITE\",\"root\":1,\"clear\":3,\"include_static_file\":null,\"constants\":null,\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0}',0,'0400$1565bd606262edff382b9db44b6c2e64:35af6288617af54964e77af08c30949a'),(7,1668273675,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"title\":\"NEW SITE\"},\"newRecord\":{\"title\":\"Default Template\"}}',0,'0400$7bd2a62cd9700e63987b33f9fa50fdd6:35af6288617af54964e77af08c30949a'),(8,1668273690,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"include_static_file\":null},\"newRecord\":{\"config\":\"\",\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:crawler_devbox_sitepackage\\/Configuration\\/TypoScript\"}}',0,'0400$ff357ccd98411c82acd915a291340742:35af6288617af54964e77af08c30949a'),(9,1668273714,1,'BE',3,0,2,'pages','{\"uid\":2,\"pid\":1,\"tstamp\":1668273714,\"crdate\":1668273714,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Search\",\"slug\":\"\\/search\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$dcd84a4379c324d5e79a65f318f3a00f:f11830df10b4b0bca2db34810c2241b3'),(10,1668273726,1,'BE',3,0,3,'pages','{\"uid\":3,\"pid\":1,\"tstamp\":1668273726,\"crdate\":1668273726,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":512,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Login\",\"slug\":\"\\/login\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$fbedf1401e674570c0623e81fe488ea3:fe15eeb7d49e64e2cea91ab53fcf0db1'),(11,1668273741,1,'BE',3,0,4,'pages','{\"uid\":4,\"pid\":1,\"tstamp\":1668273741,\"crdate\":1668273741,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":768,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Frontend Users\",\"slug\":\"\\/frontend-users\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$834336da41626eb58b27f9798831379d:412add0b3eb6ec8f1cb6710aea92e21e'),(12,1668273750,2,'BE',3,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$8ecbea2f783da4d6dfbbd9760e5a0f6e:412add0b3eb6ec8f1cb6710aea92e21e'),(13,1668273765,2,'BE',3,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$dba2a8af83c2bc242cbcdeb817ba0a29:fe15eeb7d49e64e2cea91ab53fcf0db1'),(14,1668273773,2,'BE',3,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$5c039fc63df78fef929fa41c88d743ba:f11830df10b4b0bca2db34810c2241b3'),(15,1668273824,1,'BE',3,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1668273824,\"crdate\":1668273824,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"header\",\"header\":\"Welcome - This is the TYPO3 Crawler Devbox\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_news_related_news\":0}',0,'0400$32a26f68a77e841118f225869cff8605:7fa2c035f26826fe83eeecaaeddc4d40'),(16,1668273848,2,'BE',3,0,1,'tt_content','{\"oldRecord\":{\"CType\":\"header\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"CType\":\"text\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$0fbb2720ca3e2ea8a5c23bd349ce27f4:7fa2c035f26826fe83eeecaaeddc4d40'),(17,1668273922,2,'BE',3,0,1,'tt_content','{\"oldRecord\":{\"bodytext\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"bodytext\":\"<p>Here are some links that you might find helpful.<\\/p>\\r\\n<ul> \\t<li>Docs: <a href=\\\"https:\\/\\/docs.typo3.org\\/p\\/tomasnorre\\/crawler\\/main\\/en-us\\/\\\">https:\\/\\/docs.typo3.org\\/p\\/tomasnorre\\/crawler\\/main\\/en-us\\/<\\/a><\\/li> \\t<li>Issues: <a href=\\\"https:\\/\\/github.com\\/tomasnorre\\/crawler\\/issues\\\">https:\\/\\/github.com\\/tomasnorre\\/crawler\\/issues<\\/a><\\/li> \\t<li>Repository: <a href=\\\"https:\\/\\/github.com\\/tomasnorre\\/crawler\\/\\\">https:\\/\\/github.com\\/tomasnorre\\/crawler\\/<\\/a><\\/li> \\t<li>Slack: https:\\/\\/typo3.slack.com\\/archives\\/C087NGBKM<\\/li> <\\/ul>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$873d1cd3ed444dfbdb8a173b8b61f854:7fa2c035f26826fe83eeecaaeddc4d40'),(18,1668273975,2,'BE',3,0,1,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>Here are some links that you might find helpful.<\\/p>\\r\\n<ul> \\t<li>Docs: <a href=\\\"https:\\/\\/docs.typo3.org\\/p\\/tomasnorre\\/crawler\\/main\\/en-us\\/\\\">https:\\/\\/docs.typo3.org\\/p\\/tomasnorre\\/crawler\\/main\\/en-us\\/<\\/a><\\/li> \\t<li>Issues: <a href=\\\"https:\\/\\/github.com\\/tomasnorre\\/crawler\\/issues\\\">https:\\/\\/github.com\\/tomasnorre\\/crawler\\/issues<\\/a><\\/li> \\t<li>Repository: <a href=\\\"https:\\/\\/github.com\\/tomasnorre\\/crawler\\/\\\">https:\\/\\/github.com\\/tomasnorre\\/crawler\\/<\\/a><\\/li> \\t<li>Slack: https:\\/\\/typo3.slack.com\\/archives\\/C087NGBKM<\\/li> <\\/ul>\"},\"newRecord\":{\"bodytext\":\"<p>The devbox has close to zero frontend, as most of the functionality is backend related. If there are content examples missing, please create an issue on GitHub.<\\/p>\\r\\n<p>Here are some links that you might find helpful.<\\/p>\\r\\n<ul> \\t<li>Docs: <a href=\\\"https:\\/\\/docs.typo3.org\\/p\\/tomasnorre\\/crawler\\/main\\/en-us\\/\\\">https:\\/\\/docs.typo3.org\\/p\\/tomasnorre\\/crawler\\/main\\/en-us\\/<\\/a><\\/li> \\t<li>Issues: <a href=\\\"https:\\/\\/github.com\\/tomasnorre\\/crawler\\/issues\\\">https:\\/\\/github.com\\/tomasnorre\\/crawler\\/issues<\\/a><\\/li> \\t<li>Repository: <a href=\\\"https:\\/\\/github.com\\/tomasnorre\\/crawler\\/\\\">https:\\/\\/github.com\\/tomasnorre\\/crawler\\/<\\/a><\\/li> \\t<li>Slack: https:\\/\\/typo3.slack.com\\/archives\\/C087NGBKM<\\/li> <\\/ul>\"}}',0,'0400$99dc7e661a6a05fbebb28c8f08d057e6:7fa2c035f26826fe83eeecaaeddc4d40'),(19,1668274052,1,'BE',3,0,2,'tt_content','{\"uid\":2,\"rowDescription\":\"\",\"pid\":2,\"tstamp\":1668274052,\"crdate\":1668274052,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"list\",\"header\":\"Search\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"indexedsearch_pi2\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_news_related_news\":0}',0,'0400$9a5b3068c8614991d883024bd05f72d4:01dbc21fdb1263685b9147b3b1596ea8'),(20,1668274063,2,'BE',3,0,2,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$d352db1f9577991ca61510144285aeab:01dbc21fdb1263685b9147b3b1596ea8'),(21,1668274127,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:crawler_devbox_sitepackage\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:crawler_devbox_sitepackage\\/Configuration\\/TypoScript,EXT:indexed_search\\/Configuration\\/TypoScript\"}}',0,'0400$3923700826f192f32a7feafc9e68c834:35af6288617af54964e77af08c30949a'),(22,1668274145,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:crawler_devbox_sitepackage\\/Configuration\\/TypoScript,EXT:indexed_search\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:crawler_devbox_sitepackage\\/Configuration\\/TypoScript\"}}',0,'0400$fee4870464cd243953f5947266140909:35af6288617af54964e77af08c30949a'),(23,1668274153,1,'BE',3,0,2,'sys_template','{\"uid\":2,\"pid\":2,\"tstamp\":1668274153,\"crdate\":1668274153,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"+ext\",\"root\":0,\"clear\":0,\"include_static_file\":null,\"constants\":null,\"config\":null,\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0}',0,'0400$5158cea1f1fe19302270c9dac2a86113:092a6d165d49be6de27c1b2c5d7d6698'),(24,1668274162,2,'BE',3,0,2,'sys_template','{\"oldRecord\":{\"title\":\"+ext\"},\"newRecord\":{\"title\":\"Search\"}}',0,'0400$e3fdf0e7e8dedb1e35195107a0040577:092a6d165d49be6de27c1b2c5d7d6698'),(25,1668274171,2,'BE',3,0,2,'sys_template','{\"oldRecord\":{\"include_static_file\":null},\"newRecord\":{\"include_static_file\":\"EXT:indexed_search\\/Configuration\\/TypoScript\"}}',0,'0400$4341329a7448042d4a6e126cfe83db88:092a6d165d49be6de27c1b2c5d7d6698'),(26,1668274287,1,'BE',3,0,3,'tt_content','{\"uid\":3,\"rowDescription\":\"\",\"pid\":3,\"tstamp\":1668274287,\"crdate\":1668274287,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"felogin_login\",\"header\":\"Login\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.showForgotPassword\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.showPermaLogin\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.showLogoutFormAfterLogin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.pages\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"s_redirect\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.redirectMode\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectFirstMethod\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLogin\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLoginError\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLogout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectDisable\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"s_messages\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.welcome_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.welcome_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.success_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.success_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.error_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.error_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.status_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.status_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.logout_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.logout_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.forgot_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.forgot_reset_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_news_related_news\":0}',0,'0400$53e4ee500f5c696dfd55350ef59e1c22:b92300cfb5d1d3645c9cb212a7f56c1f'),(27,1668274297,2,'BE',3,0,3,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.showForgotPassword\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.showPermaLogin\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.showLogoutFormAfterLogin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.pages\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"s_redirect\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.redirectMode\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectFirstMethod\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLogin\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLoginError\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLogout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectDisable\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"s_messages\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.welcome_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.welcome_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.success_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.success_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.error_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.error_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.status_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.status_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.logout_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.logout_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.forgot_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.forgot_reset_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.showForgotPassword\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.showPermaLogin\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.showLogoutFormAfterLogin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.pages\\\">\\n                    <value index=\\\"vDEF\\\">4<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"s_redirect\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.redirectMode\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectFirstMethod\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLogin\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLoginError\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectPageLogout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.redirectDisable\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"s_messages\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.welcome_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.welcome_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.success_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.success_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.error_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.error_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.status_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.status_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.logout_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.logout_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.forgot_header\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.forgot_reset_message\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$3705732597769c4b3bf81641b1623957:b92300cfb5d1d3645c9cb212a7f56c1f'),(28,1668274317,1,'BE',3,0,1,'fe_groups','{\"uid\":1,\"pid\":4,\"tstamp\":1668274317,\"crdate\":1668274317,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"title\":\"Website\",\"subgroup\":\"\",\"TSconfig\":\"\",\"felogin_redirectPid\":\"\"}',0,'0400$c4815db009196b324286c8cf11d0f369:74fdbe61b0d9932f32a509c1ca766543'),(29,1668274337,1,'BE',3,0,1,'fe_users','{\"uid\":1,\"pid\":4,\"tstamp\":1668274337,\"crdate\":1668274337,\"cruser_id\":3,\"deleted\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"description\":\"\",\"tx_extbase_type\":\"0\",\"username\":\"admin\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$TVVVenpqVU1HQ1Z5ZEJBbA$nycID6\\/fNzHFsupxC+OokvgqOJNaXWeAnzpgs0QA8fw\",\"usergroup\":\"1\",\"name\":\"\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"address\":\"\",\"telephone\":\"\",\"fax\":\"\",\"email\":\"\",\"uc\":null,\"title\":\"\",\"zip\":\"\",\"city\":\"\",\"country\":\"\",\"www\":\"\",\"company\":\"\",\"image\":null,\"TSconfig\":\"\",\"lastlogin\":0,\"is_online\":0,\"mfa\":null,\"felogin_redirectPid\":\"\",\"felogin_forgotHash\":\"\"}',0,'0400$cd810e458093ed78600ea6f8ac9385b2:237e89c1b2a56068427543279fe1982e'),(30,1668274364,1,'BE',3,0,5,'pages','{\"uid\":5,\"pid\":1,\"tstamp\":1668274364,\"crdate\":1668274364,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":640,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Access Restricted Page\",\"slug\":\"\\/access-restricted-page\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$b47618af921d7900af520e971e5e7f51:7ef5a4e3e11db8ac3fea4d7a75468161'),(31,1668274378,2,'BE',3,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"-2\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$3a008367ae87757834e032877658d749:7ef5a4e3e11db8ac3fea4d7a75468161'),(32,1668274404,1,'BE',3,0,4,'tt_content','{\"uid\":4,\"rowDescription\":\"\",\"pid\":5,\"tstamp\":1668274404,\"crdate\":1668274404,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"textpic\",\"header\":\"Access Restricted Page\",\"header_position\":\"\",\"bodytext\":\"<p>This page should not be visible to you if not logged in.<\\/p>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_news_related_news\":0}',0,'0400$09b8d901d38a9450311f51ebd49e3dac:4d391f5ef79b8d5d10dffa8a07ca167d'),(33,1668274428,1,'BE',3,0,6,'pages','{\"uid\":6,\"pid\":1,\"tstamp\":1668274428,\"crdate\":1668274428,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Home\",\"slug\":\"\\/home\",\"doktype\":4,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$5fab37d61cc8102a81fc6c520122d4f2:c75354c439a48dbde16b03ac553a080d'),(34,1668274445,2,'BE',3,0,6,'pages','{\"oldRecord\":{\"shortcut\":0,\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"shortcut\":\"1\",\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"shortcut_mode\\\":\\\"\\\",\\\"shortcut\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$a7a831fe4429b6d3b782796bd909a370:c75354c439a48dbde16b03ac553a080d'),(35,1668274476,2,'BE',3,0,6,'pages','{\"oldRecord\":{\"doktype\":4},\"newRecord\":{\"doktype\":\"1\"}}',0,'0400$54d56756d62f3fcb14fd5393d6046e0b:c75354c439a48dbde16b03ac553a080d'),(36,1668274478,2,'BE',3,0,6,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"shortcut_mode\\\":\\\"\\\",\\\"shortcut\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$c868cc2505a7bc9fcac5f0fe8a1cf68b:c75354c439a48dbde16b03ac553a080d'),(37,1668274497,3,'BE',3,0,1,'tt_content','{\"oldPageId\":1,\"newPageId\":6,\"oldData\":{\"header\":\"Welcome - This is the TYPO3 Crawler Devbox\",\"pid\":1,\"event_pid\":1,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274497,\"pid\":6,\"sorting\":256}}',0,'0400$937ce1a5e652f65a19bfcb893eadb96d:7fa2c035f26826fe83eeecaaeddc4d40'),(38,1668274497,2,'BE',3,0,1,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\"}\"}}',0,'0400$5364f38953dcecdbd7c8bf89d10f31a7:7fa2c035f26826fe83eeecaaeddc4d40'),(39,1668274506,2,'BE',3,0,1,'pages','{\"oldRecord\":{\"doktype\":1},\"newRecord\":{\"doktype\":\"4\"}}',0,'0400$ad84c457e37a4efb8bb6dfe93628757c:e175f7045d7ccbfb26ffcf279422c2e5'),(40,1668274512,2,'BE',3,0,1,'pages','{\"oldRecord\":{\"shortcut\":0,\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"shortcut\":\"6\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"shortcut_mode\\\":\\\"\\\",\\\"shortcut\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$a485514d938b70ec2159ad39d4626b8b:e175f7045d7ccbfb26ffcf279422c2e5'),(41,1668274630,1,'BE',3,0,7,'pages','{\"uid\":7,\"pid\":1,\"tstamp\":1668274630,\"crdate\":1668274630,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":64,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"[Default Title]\",\"slug\":\"\\/default-title\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$f55619d8e7825c2c83df6454a6942ee7:df50bb24cbce671cf0d61f42fbbef601'),(42,1668274648,2,'BE',3,0,7,'pages','{\"oldRecord\":{\"title\":\"[Default Title]\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"title\":\"Page with Subpages\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"}}',0,'0400$31a6c3fe7af31fca43d266b9b96acb70:df50bb24cbce671cf0d61f42fbbef601'),(43,1668274653,3,'BE',3,0,7,'pages','{\"oldPageId\":1,\"newPageId\":2,\"oldData\":{\"header\":\"Page with Subpages\",\"pid\":1,\"event_pid\":7,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274653,\"pid\":2,\"sorting\":256}}',0,'0400$ee4703923d021a866acf594afe30ac2f:df50bb24cbce671cf0d61f42fbbef601'),(44,1668274666,3,'BE',3,0,7,'pages','{\"oldPageId\":2,\"newPageId\":1,\"oldData\":{\"header\":\"Page with Subpages\",\"pid\":2,\"event_pid\":7,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274666,\"pid\":1,\"sorting\":576}}',0,'0400$9f99bf01ec50d8e6cf843a0ec8963cd4:df50bb24cbce671cf0d61f42fbbef601'),(45,1668274677,2,'BE',3,0,7,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$fd6f5843a2ead903e6509434926dce64:df50bb24cbce671cf0d61f42fbbef601'),(46,1668274689,1,'BE',3,0,8,'pages','{\"uid\":8,\"pid\":7,\"tstamp\":1668274689,\"crdate\":1668274689,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Subpage One\",\"slug\":\"\\/default-title\\/subpage-one\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$5eb58a3012c82958f187e2e2af939460:595375f2fb9f014e091eb08fbc51ec88'),(47,1668274698,1,'BE',3,0,9,'pages','{\"uid\":9,\"pid\":8,\"tstamp\":1668274698,\"crdate\":1668274698,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Subpage Two\",\"slug\":\"\\/default-title\\/subpage-one\\/subpage-two\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$00a7b307a6b0499904bc11eea9e59025:c5e7fa6b7b8146bdcdc78407b052e1d7'),(48,1668274708,3,'BE',3,0,9,'pages','{\"oldPageId\":8,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage Two\",\"pid\":8,\"event_pid\":9,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274708,\"pid\":7,\"sorting\":128}}',0,'0400$e8e6983c33b94c829e0ac3ee0a49dce4:c5e7fa6b7b8146bdcdc78407b052e1d7'),(49,1668274712,3,'BE',3,0,9,'pages','{\"oldPageId\":7,\"newPageId\":8,\"oldData\":{\"header\":\"Subpage Two\",\"pid\":7,\"event_pid\":9,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274712,\"pid\":8,\"sorting\":256}}',0,'0400$332e68216f3f58771a3f7bd6db05bf21:c5e7fa6b7b8146bdcdc78407b052e1d7'),(50,1668274717,3,'BE',3,0,9,'pages','{\"oldPageId\":8,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage Two\",\"pid\":8,\"event_pid\":9,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274717,\"pid\":7,\"sorting\":128}}',0,'0400$d7568a7fb888e73689f5825c116b8b5e:c5e7fa6b7b8146bdcdc78407b052e1d7'),(51,1668274721,3,'BE',3,0,9,'pages','{\"oldPageId\":7,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage Two\",\"pid\":7,\"event_pid\":9,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274721,\"pid\":7,\"sorting\":512}}',0,'0400$274d51ac58efb8dc4da885de3c8aad5a:c5e7fa6b7b8146bdcdc78407b052e1d7'),(52,1668274736,1,'BE',3,0,10,'pages','{\"uid\":10,\"pid\":1,\"tstamp\":1668274736,\"crdate\":1668274736,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":608,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Subpage Three\",\"slug\":\"\\/subpage-three\",\"doktype\":1,\"TSconfig\":\"\",\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":\"\",\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":\"\",\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":\"\",\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$a3a860f07d63647fa34b7f52f3c5b390:e904af5a60392ab3165f5849f5877e45'),(53,1668274743,3,'BE',3,0,10,'pages','{\"oldPageId\":1,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage Three\",\"pid\":1,\"event_pid\":10,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274743,\"pid\":7,\"sorting\":128}}',0,'0400$684cef18747871e0260690ad630287b6:e904af5a60392ab3165f5849f5877e45'),(54,1668274747,3,'BE',3,0,10,'pages','{\"oldPageId\":7,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage Three\",\"pid\":7,\"event_pid\":10,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274747,\"pid\":7,\"sorting\":384}}',0,'0400$a4e061241134f551a34046bcb50b01a8:e904af5a60392ab3165f5849f5877e45'),(55,1668274748,3,'BE',3,0,8,'pages','{\"oldPageId\":7,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage One\",\"pid\":7,\"event_pid\":8,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274748,\"pid\":7,\"sorting\":448}}',0,'0400$2f92b74f0c42959a967a1e11c5fa078c:595375f2fb9f014e091eb08fbc51ec88'),(56,1668274751,3,'BE',3,0,10,'pages','{\"oldPageId\":7,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage Three\",\"pid\":7,\"event_pid\":10,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274751,\"pid\":7,\"sorting\":480}}',0,'0400$3971a1c7eec8f6a74e329b6f26575b30:e904af5a60392ab3165f5849f5877e45'),(57,1668274753,3,'BE',3,0,10,'pages','{\"oldPageId\":7,\"newPageId\":7,\"oldData\":{\"header\":\"Subpage Three\",\"pid\":7,\"event_pid\":10,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668274753,\"pid\":7,\"sorting\":768}}',0,'0400$2bfe30aa972738a91d59cd3dc23c8e84:e904af5a60392ab3165f5849f5877e45'),(58,1668274755,2,'BE',3,0,9,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$61ebdf590d3623196d9e65d5e4278e1b:c5e7fa6b7b8146bdcdc78407b052e1d7'),(59,1668274755,2,'BE',3,0,8,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0bfa5140e824b635242b7cf73b1442fa:595375f2fb9f014e091eb08fbc51ec88'),(60,1668274940,1,'BE',3,0,1,'tx_crawler_configuration','{\"uid\":1,\"pid\":1,\"tstamp\":1668274940,\"crdate\":1668274940,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"name\":\"default\",\"force_ssl\":0,\"processing_instruction_filter\":\"tx_indexedsearch_reindex\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"https:\\/\\/crawler-devbox.ddev.site\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$d70c256049573fc25050dab94241dfba:6533c2b360bc1c7bfd21b125bcafeb47'),(61,1668275672,1,'BE',3,0,11,'pages','{\"uid\":11,\"pid\":1,\"tstamp\":1668275672,\"crdate\":1668275672,\"cruser_id\":3,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":544,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News\",\"slug\":\"\\/news\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$a4f3d24ddc3edc5ed9bd414e4bbdbd02:51bca2bcf14079cc366c99de31802400'),(62,1668275681,2,'BE',3,0,11,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$ed746e36aee4b3423bd092844ab2839d:51bca2bcf14079cc366c99de31802400'),(63,1668275690,1,'BE',3,0,5,'tt_content','{\"uid\":5,\"rowDescription\":\"\",\"pid\":11,\"tstamp\":1668275690,\"crdate\":1668275690,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"list\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"news_pi1\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"switchableControllerActions\\\">\\n                    <value index=\\\"vDEF\\\">News-&gt;list;News-&gt;detail<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_news_related_news\":0}',0,'0400$705755138aea51b0715dd2701372a7be:c7626fc9bcba6f70beb6ebc085a400db'),(64,1668276574,1,'BE',2,0,2,'tx_crawler_configuration','{\"uid\":2,\"pid\":1,\"tstamp\":1668276574,\"crdate\":1668276574,\"cruser_id\":2,\"deleted\":0,\"hidden\":0,\"name\":\"excludepages-6-plus-3\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"6+3\"}',0,'0400$33eae98d5be462087c2a0336bbff0210:60ad92a25ba737956a538b3d94685c25'),(65,1668277391,2,'BE',2,0,8,'pages','{\"oldRecord\":{\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$d60a593ebce1dd20516d42f406f0ced1:595375f2fb9f014e091eb08fbc51ec88'),(66,1668277404,2,'BE',2,0,7,'pages','{\"oldRecord\":{\"slug\":\"\\/default-title\"},\"newRecord\":{\"slug\":\"\\/page-with-subpages\"}}',0,'0400$258136e39951d6095e1f33eb8ee7d35b:df50bb24cbce671cf0d61f42fbbef601'),(67,1668277420,2,'BE',2,0,8,'pages','{\"oldRecord\":{\"slug\":\"\\/default-title\\/subpage-one\"},\"newRecord\":{\"slug\":\"\\/page-with-subpages\\/subpage-one\"}}',0,'0400$c02fd5a809515319edb1b0a639a6ebe3:595375f2fb9f014e091eb08fbc51ec88'),(68,1668277427,2,'BE',2,0,9,'pages','{\"oldRecord\":{\"slug\":\"\\/default-title\\/subpage-one\\/subpage-two\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"slug\":\"\\/page-with-subpages\\/subpage-two\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$b52a4ce578d68ae3aa25091a7d33f77a:c5e7fa6b7b8146bdcdc78407b052e1d7'),(69,1668277434,2,'BE',2,0,10,'pages','{\"oldRecord\":{\"slug\":\"\\/subpage-three\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"slug\":\"\\/page-with-subpages\\/subpage-three\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$a95ebfdf2a60a045cd0e4db2c135b576:e904af5a60392ab3165f5849f5877e45'),(70,1668277758,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"doktype\":4},\"newRecord\":{\"doktype\":\"1\"}}',0,'0400$2c43ffb3532f2a881116e7ff1793c058:e175f7045d7ccbfb26ffcf279422c2e5'),(71,1668277760,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"shortcut_mode\\\":\\\"\\\",\\\"shortcut\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$aa863e195b728dc7ffc6c44e77c1899a:e175f7045d7ccbfb26ffcf279422c2e5'),(72,1668277772,3,'BE',2,0,1,'tt_content','{\"oldPageId\":6,\"newPageId\":1,\"oldData\":{\"header\":\"Welcome - This is the TYPO3 Crawler Devbox\",\"pid\":6,\"event_pid\":6,\"t3ver_state\":0},\"newData\":{\"tstamp\":1668277772,\"pid\":1,\"sorting\":256}}',0,'0400$f9851dd4344604a86d7381b2359e6e57:7fa2c035f26826fe83eeecaaeddc4d40'),(73,1668277778,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"doktype\":1},\"newRecord\":{\"doktype\":\"4\"}}',0,'0400$001a45ed6e3f5e192a8832c8f89a3b49:c75354c439a48dbde16b03ac553a080d'),(74,1668277782,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"shortcut_mode\\\":\\\"\\\",\\\"shortcut\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"fe_login_mode\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$980955737c2cc43f1501867a35baec62:c75354c439a48dbde16b03ac553a080d'),(75,1668755317,2,'BE',2,0,11,'pages','{\"oldRecord\":{\"tsconfig_includes\":null},\"newRecord\":{\"tsconfig_includes\":\"EXT:news\\/Configuration\\/TSconfig\\/Page\\/news_only.tsconfig\"}}',0,'0400$9e3cd5c54dd01b4727da8738d95c4657:51bca2bcf14079cc366c99de31802400'),(76,1671197316,1,'BE',2,0,3,'tx_crawler_configuration','{\"uid\":3,\"pid\":1,\"tstamp\":1671197316,\"crdate\":1671197316,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testing\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$7efc72bac932bc2f7c6ab13702177bba:15c1c04d71be67a51103148b842105b3'),(77,1671198208,1,'BE',2,0,4,'tx_crawler_configuration','{\"uid\":4,\"pid\":1,\"tstamp\":1671198208,\"crdate\":1671198208,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"sdfasdf\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$a565d1365780afafc76d61039ec13e9d:8a6cb4b5506fbca5735108ad070cfc70'),(78,1671198680,1,'BE',2,0,5,'tx_crawler_configuration','{\"uid\":5,\"pid\":1,\"tstamp\":1671198680,\"crdate\":1671198680,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$a58227eb459d7227432770f47440d709:999588dd84008bd69c270a2f06bc475a'),(79,1671198799,1,'BE',2,0,6,'tx_crawler_configuration','{\"uid\":6,\"pid\":1,\"tstamp\":1671198799,\"crdate\":1671198799,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$eb16931eb9108be40af352c99886fd72:7d92d8c09c33607435b855ca6700e647'),(80,1671199313,4,'BE',2,0,3,'tx_crawler_configuration',NULL,0,'0400$f593e2f2e8527aff6c94b1488bbe320d:15c1c04d71be67a51103148b842105b3'),(81,1671199318,4,'BE',2,0,4,'tx_crawler_configuration',NULL,0,'0400$54fab36997ee62486d9f7f4a0a9cca5a:8a6cb4b5506fbca5735108ad070cfc70'),(82,1671199321,4,'BE',2,0,5,'tx_crawler_configuration',NULL,0,'0400$c8512829f8ea97be769bbc814f343c30:999588dd84008bd69c270a2f06bc475a'),(83,1671199324,4,'BE',2,0,6,'tx_crawler_configuration',NULL,0,'0400$187260ef8b257b986856f3c262827c17:7d92d8c09c33607435b855ca6700e647'),(84,1671199331,1,'BE',2,0,7,'tx_crawler_configuration','{\"uid\":7,\"pid\":1,\"tstamp\":1671199331,\"crdate\":1671199331,\"cruser_id\":2,\"deleted\":0,\"hidden\":0,\"name\":\"dsfasdfsdaf\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$76e61d162d41b579c16ea8cf2fb67ae9:670cacbb5e375683379a651814f0c69a'),(85,1671199337,4,'BE',2,0,7,'tx_crawler_configuration',NULL,0,'0400$debe8fb9687d9b8aee4ee5f6310b35a6:670cacbb5e375683379a651814f0c69a'),(86,1671203977,1,'BE',2,0,8,'tx_crawler_configuration','{\"uid\":8,\"pid\":1,\"tstamp\":1671203977,\"crdate\":1671203977,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$b4a79a3233f4dac1939c4b67cfed0739:0253f8857ea6f46c9392e85d18ea93e9'),(87,1671204029,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"CType\":\"list\",\"list_type\":\"news_pi1\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"CType\":\"news_pi1\",\"list_type\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"recursive\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$4555fb848063cacca7b298d04c580b59:c7626fc9bcba6f70beb6ebc085a400db'),(88,1671204031,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"switchableControllerActions\\\">\\n                    <value index=\\\"vDEF\\\">News-&gt;list;News-&gt;detail<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"recursive\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"switchableControllerActions\\\">\\n                    <value index=\\\"vDEF\\\">News-&gt;list;News-&gt;detail<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$a48e44c875185620edc4e23840cb897a:c7626fc9bcba6f70beb6ebc085a400db'),(89,1671204046,4,'BE',2,0,8,'tx_crawler_configuration',NULL,0,'0400$b0e5a6abd6f9978b551f4bcd1e309eb6:0253f8857ea6f46c9392e85d18ea93e9'),(90,1671267726,1,'BE',2,0,9,'tx_crawler_configuration','{\"uid\":9,\"pid\":1,\"tstamp\":1671267726,\"crdate\":1671267726,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$8bcfd56d7aec46d18fc5f7b3e17cf276:89f8610034676974967605f87e7629b4'),(91,1671272191,1,'BE',2,0,10,'tx_crawler_configuration','{\"uid\":10,\"pid\":1,\"tstamp\":1671272191,\"crdate\":1671272191,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$ccd21bf1b4c70f2e5054f6aa7ec1b3bd:d9dba176f033d055b2d29f62ea53dd75'),(92,1671272292,1,'BE',2,0,11,'tx_crawler_configuration','{\"uid\":11,\"pid\":1,\"tstamp\":1671272292,\"crdate\":1671272292,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$d551966e53923670035e7e43ad62b794:d5dcf3398fd15f1cbb89620a0d43bacf'),(93,1671272333,1,'BE',2,0,12,'tx_crawler_configuration','{\"uid\":12,\"pid\":1,\"tstamp\":1671272333,\"crdate\":1671272333,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$b7eb957f26abb37758d685f48a0105b7:48db414250a77afb1b356086dc9a8db8'),(94,1671274160,1,'BE',2,0,13,'tx_crawler_configuration','{\"uid\":13,\"pid\":1,\"tstamp\":1671274160,\"crdate\":1671274160,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$a275b27a9de2d3ea91804edb040136c4:0c52a5e76f8a5e7031fd405a5bd7d2b8'),(95,1671274449,1,'BE',2,0,14,'tx_crawler_configuration','{\"uid\":14,\"pid\":1,\"tstamp\":1671274449,\"crdate\":1671274449,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"name\":\"testconfiguration\",\"force_ssl\":0,\"processing_instruction_filter\":\"\",\"processing_instruction_parameters_ts\":\"\",\"configuration\":\"\",\"base_url\":\"\",\"pidsonly\":\"\",\"begroups\":\"\",\"fegroups\":\"\",\"exclude\":\"\"}',0,'0400$591dd26d89a77be54333d70aa72a81fb:7866d53e469956d0d7b4ee0d733bd7c4'),(96,1671284660,1,'BE',2,0,6,'tt_content','{\"uid\":6,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1671284660,\"crdate\":1671284660,\"cruser_id\":0,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"html\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"<button onclick=\\\"myFunction()\\\">Try it<\\/button>\\r\\n\\r\\n<p id=\\\"demo\\\"><\\/p>\\r\\n\\r\\n<script>\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";\\r\\n  }\\r\\n  document.getElementById(\\\"demo\\\").innerHTML = text;\\r\\n}\\r\\n<\\/script>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_news_related_news\":0,\"tx_impexp_origuid\":0}',0,'0400$b2e36515e60a7c51db14c83e0ed572d6:c0db6803ab1ec5f70c36e2a72187867b'),(97,1671284706,2,'BE',2,0,6,'tt_content','{\"oldRecord\":{\"bodytext\":\"<button onclick=\\\"myFunction()\\\">Try it<\\/button>\\r\\n\\r\\n<p id=\\\"demo\\\"><\\/p>\\r\\n\\r\\n<script>\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";\\r\\n  }\\r\\n  document.getElementById(\\\"demo\\\").innerHTML = text;\\r\\n}\\r\\n<\\/script>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"bodytext\":\"<button onclick=\\\"myFunction()\\\">Push Me!<\\/button>\\r\\n\\r\\n<p id=\\\"demo\\\"><\\/p>\\r\\n\\r\\n<script>\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";\\r\\n  }\\r\\n  document.getElementById(\\\"demo\\\").innerHTML = text;\\r\\n}\\r\\n<\\/script>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$51dccd08e413ca53719b45b88c840d56:c0db6803ab1ec5f70c36e2a72187867b'),(98,1671284993,2,'BE',2,0,6,'tt_content','{\"oldRecord\":{\"bodytext\":\"<button onclick=\\\"myFunction()\\\">Push Me!<\\/button>\\r\\n\\r\\n<p id=\\\"demo\\\"><\\/p>\\r\\n\\r\\n<script>\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";\\r\\n  }\\r\\n  document.getElementById(\\\"demo\\\").innerHTML = text;\\r\\n}\\r\\n<\\/script>\"},\"newRecord\":{\"bodytext\":\"<button onclick=\\\"myFunction()\\\">Try it<\\/button>\\r\\n\\r\\n<p id=\\\"demo\\\"><\\/p>\\r\\n\\r\\n<script>\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";\\r\\n  }\\r\\n  document.getElementById(\\\"demo\\\").innerHTML = text;\\r\\n}\\r\\n<\\/script>\"}}',0,'0400$bd98010667e0cb8b136ede164dce5378:c0db6803ab1ec5f70c36e2a72187867b');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (101,2,1671284994,'tt_content',6,1,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `request_id` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `level` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=550 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,0,1668273170,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1533818591: No implementation found to handle given hash. This happens if the stored hash uses a mechanism not supported by current server. Follow the documentation link to fix this issue. | TYPO3\\CMS\\Core\\Crypto\\PasswordHashing\\InvalidPasswordHashException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Crypto/PasswordHashing/PasswordHashFactory.php in line 72. Requested URL: https://crawler-devbox.ddev.site/typo3/install.php?install[controller]=maintenance',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(2,0,1668273180,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',2,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(3,0,1668273211,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(4,0,1668273227,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"tomas\";}',-1,-99,'','',0,'','info',NULL,NULL),(5,0,1668273241,3,2,2,'be_users',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:5:\"admin\";i:1;s:10:\"be_users:2\";s:7:\"history\";s:1:\"1\";}',0,0,'','',0,'','info',NULL,NULL),(6,0,1668273256,3,1,1,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW_1','',0,'','info',NULL,NULL),(7,0,1668273286,3,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";s:7:\"history\";s:1:\"3\";}',1,0,'','',0,'','info',NULL,NULL),(8,0,1668273292,3,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";s:7:\"history\";s:1:\"4\";}',1,0,'','',0,'','info',NULL,NULL),(9,0,1668273297,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1294587218: No TypoScript template found! | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/TypoScriptFrontendController.php in line 1912. Requested URL: https://crawler-devbox.ddev.site/',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(10,0,1668273621,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1294587218: No TypoScript template found! | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/TypoScriptFrontendController.php in line 1912. Requested URL: https://crawler-devbox.ddev.site/',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(11,0,1668273628,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(12,0,1668273662,3,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";s:7:\"history\";s:1:\"5\";}',1,0,'','',0,'','info',NULL,NULL),(13,0,1668273666,3,1,1,'sys_template',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW','',0,'','info',NULL,NULL),(14,0,1668273675,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:16:\"Default Template\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:1:\"7\";}',1,0,'','',0,'','info',NULL,NULL),(15,0,1668273677,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:16:\"Default Template\";i:1;s:14:\"sys_template:1\";s:7:\"history\";i:0;}',1,0,'','',0,'','info',NULL,NULL),(16,0,1668273690,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:16:\"Default Template\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:1:\"8\";}',1,0,'','',0,'','info',NULL,NULL),(17,0,1668273714,3,1,2,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:6:\"Search\";i:1;s:7:\"pages:2\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(18,0,1668273726,3,1,3,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:5:\"Login\";i:1;s:7:\"pages:3\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(19,0,1668273741,3,1,4,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:14:\"Frontend Users\";i:1;s:7:\"pages:4\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(20,0,1668273750,3,2,4,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:14:\"Frontend Users\";i:1;s:7:\"pages:4\";s:7:\"history\";s:2:\"12\";}',4,0,'','',0,'','info',NULL,NULL),(21,0,1668273765,3,2,3,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:5:\"Login\";i:1;s:7:\"pages:3\";s:7:\"history\";s:2:\"13\";}',3,0,'','',0,'','info',NULL,NULL),(22,0,1668273773,3,2,2,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:6:\"Search\";i:1;s:7:\"pages:2\";s:7:\"history\";s:2:\"14\";}',2,0,'','',0,'','info',NULL,NULL),(23,0,1668273824,3,1,1,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW636fd69361197234751616','',0,'','info',NULL,NULL),(24,0,1668273848,3,2,1,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";s:7:\"history\";s:2:\"16\";}',1,0,'','',0,'','info',NULL,NULL),(25,0,1668273922,3,2,1,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";s:7:\"history\";s:2:\"17\";}',1,0,'','',0,'','info',NULL,NULL),(26,0,1668273975,3,2,1,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";s:7:\"history\";s:2:\"18\";}',1,0,'','',0,'','info',NULL,NULL),(27,0,1668274013,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: An exception occurred while executing \'SELECT COUNT(*) FROM `index_phash`\':\n\nTable \'db.index_phash\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/AbstractMySQLDriver.php in line 61. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/IndexedSearchIsearch?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(28,0,1668274052,3,1,2,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:6:\"Search\";i:1;s:12:\"tt_content:2\";i:2;s:6:\"Search\";i:3;i:2;}',2,0,'NEW636fd77b2488b299159229','',0,'','info',NULL,NULL),(29,0,1668274054,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"tt_content.list.20.indexedsearch_pi2\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/public/typo3/sysext/fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 169. Requested URL: https://crawler-devbox.ddev.site/search',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(30,0,1668274056,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"tt_content.list.20.indexedsearch_pi2\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/public/typo3/sysext/fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 169. Requested URL: https://crawler-devbox.ddev.site/search',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(31,0,1668274063,3,2,2,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:6:\"Search\";i:1;s:12:\"tt_content:2\";s:7:\"history\";s:2:\"20\";}',2,0,'','',0,'','info',NULL,NULL),(32,0,1668274069,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"tt_content.list.20.indexedsearch_pi2\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/public/typo3/sysext/fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 169. Requested URL: https://crawler-devbox.ddev.site/search',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(33,0,1668274071,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"tt_content.list.20.indexedsearch_pi2\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/public/typo3/sysext/fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 169. Requested URL: https://crawler-devbox.ddev.site/search',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(34,0,1668274076,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(35,0,1668274077,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(36,0,1668274079,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(37,0,1668274127,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:16:\"Default Template\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"21\";}',1,0,'','',0,'','info',NULL,NULL),(38,0,1668274134,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(39,0,1668274145,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:16:\"Default Template\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"22\";}',1,0,'','',0,'','info',NULL,NULL),(40,0,1668274153,3,1,2,'sys_template',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:4:\"+ext\";i:1;s:14:\"sys_template:2\";i:2;s:6:\"Search\";i:3;i:2;}',2,0,'NEW','',0,'','info',NULL,NULL),(41,0,1668274162,3,2,2,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:6:\"Search\";i:1;s:14:\"sys_template:2\";s:7:\"history\";s:2:\"24\";}',2,0,'','',0,'','info',NULL,NULL),(42,0,1668274163,3,2,2,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:6:\"Search\";i:1;s:14:\"sys_template:2\";s:7:\"history\";i:0;}',2,0,'','',0,'','info',NULL,NULL),(43,0,1668274171,3,2,2,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:6:\"Search\";i:1;s:14:\"sys_template:2\";s:7:\"history\";s:2:\"25\";}',2,0,'','',0,'','info',NULL,NULL),(44,0,1668274175,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(45,0,1668274181,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(46,0,1668274287,3,1,3,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:5:\"Login\";i:1;s:12:\"tt_content:3\";i:2;s:5:\"Login\";i:3;i:3;}',3,0,'NEW636fd86a5e9a6873678492','',0,'','info',NULL,NULL),(47,0,1668274297,3,2,3,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:5:\"Login\";i:1;s:12:\"tt_content:3\";s:7:\"history\";s:2:\"27\";}',3,0,'','',0,'','info',NULL,NULL),(48,0,1668274307,3,1,0,'fe_groups',0,2,'SQL error: \'%s\' (%s)',1,'content',12,'172.19.0.6','a:2:{i:0;s:52:\"Unknown column \'felogin_redirectPid\' in \'field list\'\";i:1;s:35:\"fe_groups:NEW636fd88000272262011735\";}',-1,0,'','',0,'','info',NULL,NULL),(49,0,1668274317,3,1,1,'fe_groups',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:7:\"Website\";i:1;s:11:\"fe_groups:1\";i:2;s:14:\"Frontend Users\";i:3;i:4;}',4,0,'NEW636fd8836b1a4875194051','',0,'','info',NULL,NULL),(50,0,1668274337,3,1,1,'fe_users',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:5:\"admin\";i:1;s:10:\"fe_users:1\";i:2;s:14:\"Frontend Users\";i:3;i:4;}',4,0,'NEW636fd89a03d38967636667','',0,'','info',NULL,NULL),(51,0,1668274364,3,1,5,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:22:\"Access Restricted Page\";i:1;s:7:\"pages:5\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(52,0,1668274378,3,2,5,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:22:\"Access Restricted Page\";i:1;s:7:\"pages:5\";s:7:\"history\";s:2:\"31\";}',5,0,'','',0,'','info',NULL,NULL),(53,0,1668274404,3,1,4,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:22:\"Access Restricted Page\";i:1;s:12:\"tt_content:4\";i:2;s:22:\"Access Restricted Page\";i:3;i:5;}',5,0,'NEW636fd8d070f2e725355306','',0,'','info',NULL,NULL),(54,0,1668274407,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(55,0,1668274407,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(56,0,1668274409,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(57,0,1668274409,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(58,0,1668274410,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(59,0,1668274410,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(60,0,1668274413,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(61,0,1668274413,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(62,0,1668274415,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(63,0,1668274415,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(64,0,1668274415,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(65,0,1668274415,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(66,0,1668274428,3,1,6,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:4:\"Home\";i:1;s:7:\"pages:6\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(67,0,1668274445,3,2,6,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:6\";s:7:\"history\";s:2:\"34\";}',6,0,'','',0,'','info',NULL,NULL),(68,0,1668274448,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(69,0,1668274448,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(70,0,1668274451,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(71,0,1668274451,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(72,0,1668274452,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(73,0,1668274452,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(74,0,1668274453,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(75,0,1668274453,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(76,0,1668274455,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(77,0,1668274455,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(78,0,1668274456,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(79,0,1668274456,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(80,0,1668274476,3,2,6,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:6\";s:7:\"history\";s:2:\"35\";}',6,0,'','',0,'','info',NULL,NULL),(81,0,1668274478,3,2,6,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:6\";s:7:\"history\";s:2:\"36\";}',6,0,'','',0,'','info',NULL,NULL),(82,0,1668274479,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(83,0,1668274479,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(84,0,1668274481,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(85,0,1668274481,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(86,0,1668274482,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(87,0,1668274482,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(88,0,1668274483,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(89,0,1668274483,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(90,0,1668274497,3,4,1,'tt_content',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";i:2;s:4:\"Home\";i:3;i:6;}',1,0,'','',0,'','info',NULL,NULL),(91,0,1668274497,3,4,1,'tt_content',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";i:2;s:7:\"Welcome\";i:3;i:1;}',6,0,'','',0,'','info',NULL,NULL),(92,0,1668274497,3,2,1,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";s:7:\"history\";s:2:\"38\";}',6,0,'','',0,'','info',NULL,NULL),(93,0,1668274506,3,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";s:7:\"history\";s:2:\"39\";}',1,0,'','',0,'','info',NULL,NULL),(94,0,1668274512,3,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";s:7:\"history\";s:2:\"40\";}',1,0,'','',0,'','info',NULL,NULL),(95,0,1668274515,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(96,0,1668274515,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(97,0,1668274516,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(98,0,1668274516,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(99,0,1668274517,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(100,0,1668274517,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(101,0,1668274518,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(102,0,1668274518,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(103,0,1668274521,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(104,0,1668274521,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(105,0,1668274552,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(106,0,1668274558,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(107,0,1668274559,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(108,0,1668274560,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(109,0,1668274561,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(110,0,1668274562,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(111,0,1668274562,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(112,0,1668274630,3,1,7,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:15:\"[Default Title]\";i:1;s:7:\"pages:7\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(113,0,1668274633,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: An exception occurred while executing \'INSERT INTO `sys_log` (`userid`, `type`, `channel`, `level`, `action`, `error`, `details_nr`, `details`, `log_data`, `tablename`, `recuid`, `IP`, `tstamp`, `event_pid`, `NEWid`, `workspace`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)\' with params [3, 1, \"content\", \"info\", 4, 1, 14, \"Attempt to move record \'%%s\' (%%s) without having permissions to do so.\", \"a:2:{i:0;s:10:\\\"[No title]\\\";i:1;s:8:\\\"pages:-1\\\";}\", \"pages\", -1, \"172.19.0.6\", 1668274633, 0, \"\", 0]:\n\nOut of range value for column \'recuid\' at row 1 | Doctrine\\DBAL\\Exception\\DriverException thrown in file /var/www/html/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/AbstractMySQLDriver.php in line 128. Requested URL: https://crawler-devbox.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(114,0,1668274648,3,2,7,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";s:7:\"history\";s:2:\"42\";}',7,0,'','',0,'','info',NULL,NULL),(115,0,1668274653,3,4,7,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";i:2;s:6:\"Search\";i:3;i:2;}',1,0,'','',0,'','info',NULL,NULL),(116,0,1668274653,3,4,7,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";i:2;s:7:\"Welcome\";i:3;i:1;}',2,0,'','',0,'','info',NULL,NULL),(117,0,1668274666,3,4,7,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";i:2;s:7:\"Welcome\";i:3;i:1;}',2,0,'','',0,'','info',NULL,NULL),(118,0,1668274666,3,4,7,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";i:2;s:6:\"Search\";i:3;i:2;}',1,0,'','',0,'','info',NULL,NULL),(119,0,1668274677,3,2,7,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";s:7:\"history\";s:2:\"45\";}',7,0,'','',0,'','info',NULL,NULL),(120,0,1668274689,3,1,8,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:11:\"Subpage One\";i:1;s:7:\"pages:8\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',7,0,'NEW_1','',0,'','info',NULL,NULL),(121,0,1668274698,3,1,9,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:11:\"Subpage One\";i:3;i:8;}',8,0,'NEW_1','',0,'','info',NULL,NULL),(122,0,1668274708,3,4,9,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',8,0,'','',0,'','info',NULL,NULL),(123,0,1668274708,3,4,9,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:11:\"Subpage One\";i:3;i:8;}',7,0,'','',0,'','info',NULL,NULL),(124,0,1668274712,3,4,9,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:11:\"Subpage One\";i:3;i:8;}',7,0,'','',0,'','info',NULL,NULL),(125,0,1668274712,3,4,9,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',8,0,'','',0,'','info',NULL,NULL),(126,0,1668274717,3,4,9,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',8,0,'','',0,'','info',NULL,NULL),(127,0,1668274717,3,4,9,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:11:\"Subpage One\";i:3;i:8;}',7,0,'','',0,'','info',NULL,NULL),(128,0,1668274721,3,4,9,'pages',0,0,'Moved record \'%s\' (%s) on page \'%s\' (%s)',1,'content',4,'172.19.0.6','a:4:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',7,0,'','',0,'','info',NULL,NULL),(129,0,1668274736,3,1,10,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:13:\"Subpage Three\";i:1;s:8:\"pages:10\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW636fda27ef10e714652616','',0,'','info',NULL,NULL),(130,0,1668274743,3,4,10,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:13:\"Subpage Three\";i:1;s:8:\"pages:10\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',1,0,'','',0,'','info',NULL,NULL),(131,0,1668274743,3,4,10,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:13:\"Subpage Three\";i:1;s:8:\"pages:10\";i:2;s:7:\"Welcome\";i:3;i:1;}',7,0,'','',0,'','info',NULL,NULL),(132,0,1668274747,3,4,10,'pages',0,0,'Moved record \'%s\' (%s) on page \'%s\' (%s)',1,'content',4,'172.19.0.6','a:4:{i:0;s:13:\"Subpage Three\";i:1;s:8:\"pages:10\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',7,0,'','',0,'','info',NULL,NULL),(133,0,1668274748,3,4,8,'pages',0,0,'Moved record \'%s\' (%s) on page \'%s\' (%s)',1,'content',4,'172.19.0.6','a:4:{i:0;s:11:\"Subpage One\";i:1;s:7:\"pages:8\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',7,0,'','',0,'','info',NULL,NULL),(134,0,1668274751,3,4,10,'pages',0,0,'Moved record \'%s\' (%s) on page \'%s\' (%s)',1,'content',4,'172.19.0.6','a:4:{i:0;s:13:\"Subpage Three\";i:1;s:8:\"pages:10\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',7,0,'','',0,'','info',NULL,NULL),(135,0,1668274753,3,4,10,'pages',0,0,'Moved record \'%s\' (%s) on page \'%s\' (%s)',1,'content',4,'172.19.0.6','a:4:{i:0;s:13:\"Subpage Three\";i:1;s:8:\"pages:10\";i:2;s:18:\"Page with Subpages\";i:3;i:7;}',7,0,'','',0,'','info',NULL,NULL),(136,0,1668274755,3,2,9,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";s:7:\"history\";s:2:\"58\";}',9,0,'','',0,'','info',NULL,NULL),(137,0,1668274755,3,2,8,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:11:\"Subpage One\";i:1;s:7:\"pages:8\";s:7:\"history\";s:2:\"59\";}',8,0,'','',0,'','info',NULL,NULL),(138,0,1668274759,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(139,0,1668274761,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(140,0,1668274763,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(141,0,1668274774,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(142,0,1668274774,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(143,0,1668274775,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(144,0,1668274776,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(145,0,1668274803,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:16:\"Default Template\";i:1;s:14:\"sys_template:1\";s:7:\"history\";i:0;}',1,0,'','',0,'','info',NULL,NULL),(146,0,1668274940,3,1,1,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:7:\"default\";i:1;s:26:\"tx_crawler_configuration:1\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW636fdae7cdcee399657441','',0,'','info',NULL,NULL),(147,0,1668274995,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(148,0,1668274998,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(149,0,1668275001,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(150,0,1668275007,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(151,0,1668275013,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(152,0,1668275019,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(153,0,1668275024,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(154,0,1668275030,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(155,0,1668275035,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(156,0,1668275041,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(157,0,1668275149,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(158,0,1668275152,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(159,0,1668275155,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(160,0,1668275172,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(161,0,1668275190,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(162,0,1668275210,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(163,0,1668275229,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(164,0,1668275249,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(165,0,1668275268,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(166,0,1668275287,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(167,0,1668275305,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(168,0,1668275324,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(169,0,1668275342,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(170,0,1668275360,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(171,0,1668275378,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(172,0,1668275395,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(173,0,1668275397,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/news',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(174,0,1668275496,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(175,0,1668275498,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(176,0,1668275499,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(177,0,1668275500,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(178,0,1668275672,3,1,11,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:4:\"News\";i:1;s:8:\"pages:11\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(179,0,1668275681,3,2,11,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"News\";i:1;s:8:\"pages:11\";s:7:\"history\";s:2:\"62\";}',11,0,'','',0,'','info',NULL,NULL),(180,0,1668275690,3,1,5,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:5\";i:2;s:4:\"News\";i:3;i:11;}',11,0,'NEW636fdde7d2a0f032840840','',0,'','info',NULL,NULL),(181,0,1668275693,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(182,0,1668275696,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(183,0,1668275697,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(184,0,1668275698,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(185,0,1668275734,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(186,0,1668275737,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(187,0,1668275740,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(188,0,1668275741,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"tomas\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(189,0,1668275741,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(190,0,1668275760,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(191,0,1668275767,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(192,0,1668275784,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(193,0,1668275802,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(194,0,1668275820,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(195,0,1668275837,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(196,0,1668275854,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(197,0,1668275871,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(198,0,1668275889,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(199,0,1668275906,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(200,0,1668275913,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(201,0,1668275930,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(202,0,1668275947,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(203,0,1668275948,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(204,0,1668276318,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(205,0,1668276438,3,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"tomas\";}',-1,0,'','',0,'','info',NULL,NULL),(206,0,1668276442,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(207,0,1668276453,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(208,0,1668276574,2,1,2,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:21:\"excludepages-6-plus-3\";i:1;s:26:\"tx_crawler_configuration:2\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW636fe142cd43a695182342','',0,'','info',NULL,NULL),(209,0,1668276582,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(210,0,1668276606,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(211,0,1668276610,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(212,0,1668276613,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(213,0,1668276622,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(214,0,1668276631,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(215,0,1668276640,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(216,0,1668276664,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(217,0,1668276688,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(218,0,1668276712,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(219,0,1668276722,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(220,0,1668276748,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(221,0,1668276772,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(222,0,1668276798,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(223,0,1668276823,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(224,0,1668276834,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(225,0,1668276843,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(226,0,1668276844,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(227,0,1668276948,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(228,0,1668276951,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(229,0,1668276955,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(230,0,1668276963,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(231,0,1668276972,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(232,0,1668276979,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(233,0,1668277004,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(234,0,1668277029,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(235,0,1668277054,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(236,0,1668277067,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(237,0,1668277092,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(238,0,1668277118,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(239,0,1668277142,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(240,0,1668277166,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(241,0,1668277178,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(242,0,1668277186,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(243,0,1668277187,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(244,0,1668277391,2,2,8,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:11:\"Subpage One\";i:1;s:7:\"pages:8\";s:7:\"history\";s:2:\"65\";}',8,0,'','',0,'','info',NULL,NULL),(245,0,1668277404,2,2,7,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";s:7:\"history\";s:2:\"66\";}',7,0,'','',0,'','info',NULL,NULL),(246,0,1668277407,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(247,0,1668277411,2,2,7,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:18:\"Page with Subpages\";i:1;s:7:\"pages:7\";s:7:\"history\";i:0;}',7,0,'','',0,'','info',NULL,NULL),(248,0,1668277420,2,2,8,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:11:\"Subpage One\";i:1;s:7:\"pages:8\";s:7:\"history\";s:2:\"67\";}',8,0,'','',0,'','info',NULL,NULL),(249,0,1668277427,2,2,9,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:11:\"Subpage Two\";i:1;s:7:\"pages:9\";s:7:\"history\";s:2:\"68\";}',9,0,'','',0,'','info',NULL,NULL),(250,0,1668277434,2,2,10,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:13:\"Subpage Three\";i:1;s:8:\"pages:10\";s:7:\"history\";s:2:\"69\";}',10,0,'','',0,'','info',NULL,NULL),(251,0,1668277457,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113',5,'php',0,'','',-1,0,'','',0,'','info',NULL,NULL),(252,0,1668277457,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113',5,'php',0,'','',-1,0,'','',0,'','info',NULL,NULL),(253,0,1668277457,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113',5,'php',0,'','',-1,0,'','',0,'','info',NULL,NULL),(254,0,1668277457,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113',5,'php',0,'','',-1,0,'','',0,'','info',NULL,NULL),(255,0,1668277501,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(256,0,1668277502,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(257,0,1668277502,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(258,0,1668277504,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(259,0,1668277505,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(260,0,1668277554,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(261,0,1668277758,2,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";s:7:\"history\";s:2:\"70\";}',1,0,'','',0,'','info',NULL,NULL),(262,0,1668277760,2,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:7:\"Welcome\";i:1;s:7:\"pages:1\";s:7:\"history\";s:2:\"71\";}',1,0,'','',0,'','info',NULL,NULL),(263,0,1668277772,2,4,1,'tt_content',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,'content',2,'172.19.0.6','a:4:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";i:2;s:7:\"Welcome\";i:3;i:1;}',6,0,'','',0,'','info',NULL,NULL),(264,0,1668277772,2,4,1,'tt_content',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,'content',3,'172.19.0.6','a:4:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";i:2;s:4:\"Home\";i:3;i:6;}',1,0,'','',0,'','info',NULL,NULL),(265,0,1668277772,2,2,1,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:42:\"Welcome - This is the TYPO3 Crawler Devbox\";i:1;s:12:\"tt_content:1\";s:7:\"history\";i:0;}',1,0,'','',0,'','info',NULL,NULL),(266,0,1668277778,2,2,6,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:6\";s:7:\"history\";s:2:\"73\";}',6,0,'','',0,'','info',NULL,NULL),(267,0,1668277782,2,2,6,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:6\";s:7:\"history\";s:2:\"74\";}',6,0,'','',0,'','info',NULL,NULL),(268,0,1668277790,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(269,0,1668277793,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(270,0,1668277796,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(271,0,1668277804,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(272,0,1668277812,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(273,0,1668277820,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(274,0,1668277829,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(275,0,1668277838,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(276,0,1668277847,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(277,0,1668277857,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(278,0,1668277869,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(279,0,1668277883,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(280,0,1668277897,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(281,0,1668277908,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(282,0,1668277920,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.96.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(283,0,1668277928,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(284,0,1668277929,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.96.5','',-1,0,'','',0,'','info',NULL,NULL),(285,0,1668330193,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(286,0,1668330248,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(287,0,1668330251,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(288,0,1668330254,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(289,0,1668330272,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(290,0,1668330347,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(291,0,1668330501,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(292,0,1668754264,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(293,0,1668754264,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(294,0,1668754266,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(295,0,1668754266,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(296,0,1668754267,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(297,0,1668754267,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(298,0,1668754269,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(299,0,1668754269,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(300,0,1668754270,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(301,0,1668754270,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(302,0,1668754270,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(303,0,1668754270,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(304,0,1668754738,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(305,0,1668754742,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(306,0,1668754747,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(307,0,1668754757,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(308,0,1668754768,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(309,0,1668754778,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(310,0,1668754788,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(311,0,1668754798,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(312,0,1668754808,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(313,0,1668754818,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(314,0,1668754830,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(315,0,1668754844,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(316,0,1668754858,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(317,0,1668754869,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(318,0,1668754881,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.144.5','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(319,0,1668754890,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'192.168.144.5','',-1,0,'','',0,'','info',NULL,NULL),(320,0,1668754890,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.144.5','',-1,0,'','',0,'','info',NULL,NULL),(321,0,1668754891,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'192.168.144.5','',-1,0,'','',0,'','info',NULL,NULL),(322,0,1668754891,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"http://web/access-restricted-page\", reason: Client error: `GET http://web/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: http://web/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'192.168.144.5','',-1,0,'','',0,'','info',NULL,NULL),(323,0,1668755172,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',2,'172.19.0.6','a:1:{i:0;s:10:\"tomasnorre\";}',-1,-99,'','',0,'','info',NULL,NULL),(324,0,1668755177,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(325,0,1668755197,2,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(326,0,1668755198,2,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(327,0,1668755218,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(328,0,1668755218,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(329,0,1668755221,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(330,0,1668755221,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(331,0,1668755223,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(332,0,1668755223,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(333,0,1668755224,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(334,0,1668755224,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(335,0,1668755317,2,2,11,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"News\";i:1;s:8:\"pages:11\";s:7:\"history\";s:2:\"75\";}',11,0,'','',0,'','info',NULL,NULL),(336,0,1668755321,2,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(337,0,1668755322,2,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.19.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(338,0,1668755325,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(339,0,1668755325,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172838: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", reason: Client error: `GET https://crawler-devbox.ddev.site/access-restricted-page` resulted in a `403 Forbidden` response:\n<!DOCTYPE html>\n\n<head>\n    <meta charset=\"utf-8\">\n    <meta name=\"robots\" content=\"noindex, follow\">\n    <meta name=\"vi (truncated...)\n | RuntimeException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 113. Requested URL: https://crawler-devbox.ddev.site/typo3temp/assets/css/7015c8c4ac5ff815b57530b221005fc6.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(340,0,1668755434,2,2,11,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.19.0.6','a:3:{i:0;s:4:\"News\";i:1;s:8:\"pages:11\";s:7:\"history\";i:0;}',11,0,'','',0,'','info',NULL,NULL),(341,0,1671173132,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(342,0,1671173133,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: gzuncompress(): data error in /var/www/html/public/typo3/sysext/core/Classes/Cache/Backend/Typo3DatabaseBackend.php line 157 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 137. Requested URL: https://crawler-devbox.ddev.site/typo3/main?token=--AnonymizedToken--',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(343,0,1671173190,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method TYPO3\\CMS\\Backend\\Template\\ModuleTemplate::makeDocHeaderModuleMenu() | Error thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Controller/Backend/BackendModuleStartCrawlingController.php in line 67. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(344,0,1671173839,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method TYPO3\\CMS\\Backend\\Template\\ModuleTemplate::makeDocHeaderModuleMenu() | Error thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Controller/Backend/BackendModuleStartCrawlingController.php in line 67. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(345,0,1671197180,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(346,0,1671197194,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1441706370: Button \"TYPO3\\CMS\\Backend\\Template\\Components\\Buttons\\Action\\ShortcutButton\" is not valid | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-backend/Classes/Template/Components/ButtonBar.php in line 69. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(347,0,1671197199,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1441706370: Button \"TYPO3\\CMS\\Backend\\Template\\Components\\Buttons\\Action\\ShortcutButton\" is not valid | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-backend/Classes/Template/Components/ButtonBar.php in line 69. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(348,0,1671197200,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: https://crawler-devbox.ddev.site/typo3conf/ext/crawler_devbox_sitepackage/Resources/Public/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(349,0,1671197202,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1441706370: Button \"TYPO3\\CMS\\Backend\\Template\\Components\\Buttons\\Action\\ShortcutButton\" is not valid | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-backend/Classes/Template/Components/ButtonBar.php in line 69. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(350,0,1671197211,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1441706370: Button \"TYPO3\\CMS\\Backend\\Template\\Components\\Buttons\\Action\\ShortcutButton\" is not valid | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-backend/Classes/Template/Components/ButtonBar.php in line 69. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(351,0,1671197222,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1441706370: Button \"TYPO3\\CMS\\Backend\\Template\\Components\\Buttons\\Action\\ShortcutButton\" is not valid | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-backend/Classes/Template/Components/ButtonBar.php in line 69. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(352,0,1671197227,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1441706370: Button \"TYPO3\\CMS\\Backend\\Template\\Components\\Buttons\\Action\\ShortcutButton\" is not valid | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-backend/Classes/Template/Components/ButtonBar.php in line 69. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(353,0,1671197316,2,1,3,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.6','{\"title\":\"testing\",\"table\":\"tx_crawler_configuration\",\"uid\":3,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639c72808e841519183472','',0,'','info',NULL,NULL),(354,0,1671197316,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Class \"TYPO3\\CMS\\Extbase\\Object\\ObjectManager\" not found | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Utility/GeneralUtility.php in line 2962. Requested URL: https://crawler-devbox.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_crawler_configuration%%5D%%5B1%%5D=new&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D1%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(355,0,1671197535,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(356,0,1671197538,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(357,0,1671197542,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(358,0,1671197553,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(359,0,1671197564,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(360,0,1671197575,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(361,0,1671197589,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(362,0,1671197598,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(363,0,1671197607,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(364,0,1671197616,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(365,0,1671197627,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(366,0,1671197640,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(367,0,1671197653,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(368,0,1671197663,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(369,0,1671197674,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(370,0,1671197686,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(371,0,1671197710,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(372,0,1671197723,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(373,0,1671197740,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(374,0,1671197760,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(375,0,1671197772,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(376,0,1671197781,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(377,0,1671197782,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"tt_content.list.20.news_pi1\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 160. Requested URL: http://web/news',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(378,0,1671198208,2,1,4,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.6','{\"title\":\"sdfasdf\",\"table\":\"tx_crawler_configuration\",\"uid\":4,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639c7517e7244879712882','',0,'','info',NULL,NULL),(379,0,1671198208,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Class \"TYPO3\\CMS\\Extbase\\Object\\ObjectManager\" not found | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Utility/GeneralUtility.php in line 2962. Requested URL: https://crawler-devbox.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_crawler_configuration%%5D%%5B1%%5D=new&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D1%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(380,0,1671198259,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(381,0,1671198411,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(382,0,1671198671,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(383,0,1671198680,2,1,5,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":5,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639c77d68b3ff314326065','',0,'','info',NULL,NULL),(384,0,1671198680,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Class \"TYPO3\\CMS\\Extbase\\Object\\ObjectManager\" not found | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Utility/GeneralUtility.php in line 2962. Requested URL: http://web/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btx_crawler_configuration%%5D%%5B1%%5D=new&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Flist%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D1%%26table%%3D%%26pointer%%3D1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(385,0,1671198792,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(386,0,1671198799,2,1,6,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":6,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639c784ebd464516378995','',0,'','info',NULL,NULL),(387,0,1671199260,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(388,0,1671199261,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: gzuncompress(): data error in /var/www/html/public/typo3/sysext/core/Classes/Cache/Backend/Typo3DatabaseBackend.php line 157 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/public/typo3/sysext/core/Classes/Error/ErrorHandler.php in line 137. Requested URL: https://crawler-devbox.ddev.site/typo3/main?token=--AnonymizedToken--&redirect=record_edit&redirectParams=edit%%255Btx_crawler_configuration%%255D%%255B1%%255D%%3Dnew',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(389,0,1671199313,2,3,3,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.19.0.6','a:4:{i:0;s:7:\"testing\";i:1;s:26:\"tx_crawler_configuration:3\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'','',0,'','info',NULL,NULL),(390,0,1671199318,2,3,4,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.19.0.6','a:4:{i:0;s:7:\"sdfasdf\";i:1;s:26:\"tx_crawler_configuration:4\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'','',0,'','info',NULL,NULL),(391,0,1671199321,2,3,5,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.19.0.6','a:4:{i:0;s:17:\"testconfiguration\";i:1;s:26:\"tx_crawler_configuration:5\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'','',0,'','info',NULL,NULL),(392,0,1671199324,2,3,6,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.19.0.6','a:4:{i:0;s:17:\"testconfiguration\";i:1;s:26:\"tx_crawler_configuration:6\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'','',0,'','info',NULL,NULL),(393,0,1671199331,2,1,7,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.19.0.6','a:4:{i:0;s:11:\"dsfasdfsdaf\";i:1;s:26:\"tx_crawler_configuration:7\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'NEW639c7a5f8b37a025227926','',0,'','info',NULL,NULL),(394,0,1671199337,2,3,7,'tx_crawler_configuration',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.19.0.6','a:4:{i:0;s:11:\"dsfasdfsdaf\";i:1;s:26:\"tx_crawler_configuration:7\";i:2;s:7:\"Welcome\";i:3;i:1;}',1,0,'','',0,'','info',NULL,NULL),(395,0,1671199353,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method TYPO3\\CMS\\Backend\\Template\\ModuleTemplate::makeDocHeaderModuleMenu() | Error thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Controller/Backend/BackendModuleStartCrawlingController.php in line 67. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(396,0,1671200698,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method TYPO3\\CMS\\Backend\\Template\\ModuleTemplate::makeDocHeaderModuleMenu() | Error thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Controller/Backend/BackendModuleStartCrawlingController.php in line 67. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(397,0,1671200704,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method TYPO3\\CMS\\Backend\\Template\\ModuleTemplate::makeDocHeaderModuleMenu() | Error thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Controller/Backend/BackendModuleStartCrawlingController.php in line 67. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(398,0,1671200712,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Too few arguments to function AOE\\Crawler\\Backend\\RequestForm\\StartRequestForm::__construct(), 0 passed in /var/www/html/public/typo3/sysext/core/Classes/Utility/GeneralUtility.php on line 3221 and at least 3 expected | ArgumentCountError thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Backend/RequestForm/StartRequestForm.php in line 41. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(399,0,1671200901,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1442431631: Object \"AOE\\Crawler\\Backend\\RequestForm\\RequestFormFactory\" doesn\'t implement an __invoke() method and cannot be used as target. | InvalidArgumentException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Http/Dispatcher.php in line 78. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(400,0,1671200922,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1442431631: Object \"AOE\\Crawler\\Backend\\RequestForm\\RequestFormFactory\" doesn\'t implement an __invoke() method and cannot be used as target. | InvalidArgumentException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Http/Dispatcher.php in line 78. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(401,0,1671200930,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: AOE\\Crawler\\Backend\\RequestForm\\RequestFormFactory::create(): Argument #1 ($selectedAction) must be of type AOE\\Crawler\\Value\\CrawlAction, TYPO3\\CMS\\Core\\Http\\ServerRequest given, called in /var/www/html/public/typo3/sysext/backend/Classes/Http/RouteDispatcher.php on line 91 | TypeError thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Backend/RequestForm/RequestFormFactory.php in line 35. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(402,0,1671201714,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Backend\\Http\\RouteDispatcher::dispatch(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, null returned | TypeError thrown in file /var/www/html/public/typo3/sysext/backend/Classes/Http/RouteDispatcher.php in line 91. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(403,0,1671202063,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Backend\\Http\\RouteDispatcher::dispatch(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, null returned | TypeError thrown in file /var/www/html/public/typo3/sysext/backend/Classes/Http/RouteDispatcher.php in line 91. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(404,0,1671203168,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method TYPO3\\CMS\\Backend\\Template\\ModuleTemplate::makeDocHeaderModuleMenu() | Error thrown in file /var/www/html/public/typo3conf/ext/crawler/Classes/Controller/Backend/BackendModuleStartCrawlingController.php in line 67. Requested URL: https://crawler-devbox.ddev.site/typo3/module/web/CrawlerStart?token=--AnonymizedToken--&id=1&',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(405,0,1671203239,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(406,0,1671203730,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(407,0,1671203734,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(408,0,1671203738,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(409,0,1671203746,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(410,0,1671203754,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(411,0,1671203762,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(412,0,1671203771,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(413,0,1671203781,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(414,0,1671203791,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(415,0,1671203800,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(416,0,1671203812,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(417,0,1671203825,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(418,0,1671203838,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(419,0,1671203849,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(420,0,1671203860,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(421,0,1671203874,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(422,0,1671203899,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(423,0,1671203912,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(424,0,1671203931,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(425,0,1671203949,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(426,0,1671203961,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(427,0,1671203970,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(428,0,1671203977,2,1,8,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":8,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639c8c88807b2620743317','',0,'','info',NULL,NULL),(429,0,1671203979,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(430,0,1671203980,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"tt_content.list.20.news_pi1\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 160. Requested URL: http://web/news',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(431,0,1671204029,2,2,5,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.6','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":5,\"history\":\"87\"}',11,0,'','',0,'','info',NULL,NULL),(432,0,1671204031,2,2,5,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.6','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":5,\"history\":\"88\"}',11,0,'','',0,'','info',NULL,NULL),(433,0,1671204046,2,3,8,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.19.0.6','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":8,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),(434,0,1671266526,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: https://crawler-devbox.ddev.site/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(435,0,1671266534,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.19.0.6','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(436,0,1671267454,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(437,0,1671267459,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(438,0,1671267465,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(439,0,1671267476,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(440,0,1671267489,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(441,0,1671267503,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(442,0,1671267515,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(443,0,1671267528,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(444,0,1671267543,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(445,0,1671267556,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(446,0,1671267567,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(447,0,1671267579,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(448,0,1671267591,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(449,0,1671267602,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(450,0,1671267612,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(451,0,1671267624,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(452,0,1671267647,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(453,0,1671267660,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(454,0,1671267678,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(455,0,1671267697,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(456,0,1671267709,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(457,0,1671267719,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(458,0,1671267726,2,1,9,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":9,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639d858cb18fd152867584','',0,'','info',NULL,NULL),(459,0,1671267727,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(460,0,1671267728,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(461,0,1671267918,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(462,0,1671268009,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(463,0,1671268152,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(464,0,1671268344,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(465,0,1671268626,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(466,0,1671268877,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(467,0,1671269028,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(468,0,1671272057,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(469,0,1671272184,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(470,0,1671272191,2,1,10,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":10,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639d96fe32a36886648796','',0,'','info',NULL,NULL),(471,0,1671272285,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(472,0,1671272292,2,1,11,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":11,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639d9762e8756001965295','',0,'','info',NULL,NULL),(473,0,1671272326,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(474,0,1671272333,2,1,12,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":12,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639d978c14237255202383','',0,'','info',NULL,NULL),(475,0,1671272344,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(476,0,1671272522,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(477,0,1671273936,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(478,0,1671273939,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(479,0,1671273943,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(480,0,1671273950,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(481,0,1671273958,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(482,0,1671273965,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(483,0,1671273974,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(484,0,1671273983,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(485,0,1671273992,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(486,0,1671274001,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(487,0,1671274012,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(488,0,1671274024,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(489,0,1671274036,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(490,0,1671274046,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(491,0,1671274056,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(492,0,1671274069,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(493,0,1671274082,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(494,0,1671274095,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(495,0,1671274112,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(496,0,1671274132,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(497,0,1671274144,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(498,0,1671274153,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(499,0,1671274160,2,1,13,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":13,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639d9eaf6c3fe944193197','',0,'','info',NULL,NULL),(500,0,1671274161,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(501,0,1671274162,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(502,0,1671274220,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(503,0,1671274223,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(504,0,1671274227,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(505,0,1671274234,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(506,0,1671274242,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(507,0,1671274250,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(508,0,1671274260,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(509,0,1671274269,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(510,0,1671274278,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(511,0,1671274287,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(512,0,1671274297,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(513,0,1671274309,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(514,0,1671274321,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(515,0,1671274331,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(516,0,1671274341,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(517,0,1671274355,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(518,0,1671274370,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(519,0,1671274383,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(520,0,1671274400,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(521,0,1671274421,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(522,0,1671274433,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(523,0,1671274442,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(524,0,1671274449,2,1,14,'tx_crawler_configuration',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"testconfiguration\",\"table\":\"tx_crawler_configuration\",\"uid\":14,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639d9fd08a598255150317','',0,'','info',NULL,NULL),(525,0,1671274450,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(526,0,1671274451,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(527,0,1671275798,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(528,0,1671275950,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL),(529,0,1671284589,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: https://crawler-devbox.ddev.site/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(530,0,1671284597,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: https://crawler-devbox.ddev.site/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(531,0,1671284660,2,1,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.19.0.6','{\"title\":\"Try it\\r\\n\\r\\n\\r\\n\\r\\n\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";\\r\\n...\",\"table\":\"tt_content\",\"uid\":6,\"pageTitle\":\"Welcome\",\"pid\":1}',1,0,'NEW639dc78c7ef94737836863','',0,'','info',NULL,NULL),(532,0,1671284663,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"https://crawler-devbox.ddev.site/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: https://crawler-devbox.ddev.site/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.19.0.6','',-1,0,'','',0,'','info',NULL,NULL),(533,0,1671284706,2,2,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.6','{\"title\":\"Push Me!\\r\\n\\r\\n\\r\\n\\r\\n\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";...\",\"table\":\"tt_content\",\"uid\":6,\"history\":\"97\"}',1,0,'','',0,'','info',NULL,NULL),(534,0,1671284833,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(535,0,1671284834,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(536,0,1671284834,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(537,0,1671284904,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(538,0,1671284905,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(539,0,1671284905,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(540,0,1671284993,2,2,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.19.0.6','{\"title\":\"Try it\\r\\n\\r\\n\\r\\n\\r\\n\\r\\nfunction myFunction() {\\r\\n  let text = \\\"Press a button!\\\\nEither OK or Cancel.\\\";\\r\\n  if (confirm(text) == true) {\\r\\n    text = \\\"You pressed OK!\\\";\\r\\n  } else {\\r\\n    text = \\\"You canceled!\\\";\\r\\n...\",\"table\":\"tt_content\",\"uid\":6,\"history\":\"98\"}',1,0,'','',0,'','info',NULL,NULL),(541,0,1671285015,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(542,0,1671285016,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(543,0,1671285016,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(544,0,1671285184,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(545,0,1671285185,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(546,0,1671285185,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/https://www.w3schools.com/JSREF/tryit.asp?filename=tryjsref_confirm3',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(547,0,1671285237,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(548,0,1671285238,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL),(549,0,1671285238,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1544172839: Error handler could not fetch error page \"http://web/access-restricted-page\", status code: 403 | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/PageContentErrorHandler.php in line 87. Requested URL: http://web/_assets/2e7261a1162a6e2b263c8b04e08ae26d/Css/fontawesome-all.min.css',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_preview`
--

DROP TABLE IF EXISTS `sys_preview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_preview` (
  `keyword` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_preview`
--

LOCK TABLES `sys_preview` WRITE;
/*!40000 ALTER TABLE `sys_preview` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_preview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdby` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `source_host` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `source_path` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `protected` smallint(5) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target_statuscode` int(11) NOT NULL DEFAULT 307,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `lasthiton` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('001cd2e4390e0152274a1a31cabbf067','fe_users',1,'usergroup','','','',0,0,'fe_groups',1,''),('49f46b21faf37f136b0e8b403692dc2a','pages',6,'shortcut','','','',0,0,'pages',1,''),('98abb1faa6b24ac496a9a69434df0210','tt_content',3,'pi_flexform','sDEF/lDEF/settings.pages/vDEF/','','',0,0,'pages',4,''),('99e85ce3c878cb7412e9de00472e4a4a','pages',1,'shortcut','','','',0,0,'pages',6,''),('b2b391ee1a6751ca39748e66859c0ec7','pages',5,'fe_group','','','',0,0,'fe_groups',-2,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (2,'core','formProtectionSessionToken:2','s:64:\"742d768feb1112374c7d119772bf3d2095bea942ca438279862c36cf0de2da78\";'),(3,'tx_scheduler','lastRun','a:3:{s:5:\"start\";i:1671352802;s:3:\"end\";i:1671352802;s:4:\"type\";s:4:\"cron\";}');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `basedOn` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1668274145,1668273666,3,0,0,0,0,256,NULL,0,0,0,0,0,'Default Template',1,3,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/Styling/,EXT:crawler_devbox_sitepackage/Configuration/TypoScript',NULL,'','',0,0,0),(2,2,1668274171,1668274153,3,0,0,0,0,256,NULL,0,0,0,0,0,'Search',0,0,'EXT:indexed_search/Configuration/TypoScript',NULL,NULL,'',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace`
--

DROP TABLE IF EXISTS `sys_workspace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_workspace` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `adminusers` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `members` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish_time` int(11) NOT NULL DEFAULT 0,
  `freeze` smallint(6) NOT NULL DEFAULT 0,
  `live_edit` smallint(6) NOT NULL DEFAULT 0,
  `publish_access` smallint(6) NOT NULL DEFAULT 0,
  `previewlink_lifetime` int(11) NOT NULL DEFAULT 0,
  `custom_stages` int(11) NOT NULL DEFAULT 0,
  `stagechg_notification` smallint(6) NOT NULL DEFAULT 0,
  `edit_notification_defaults` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `edit_notification_preselection` smallint(6) NOT NULL DEFAULT 3,
  `edit_allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  `publish_notification_defaults` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `publish_notification_preselection` smallint(6) NOT NULL DEFAULT 3,
  `publish_allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  `execute_notification_defaults` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `execute_notification_preselection` smallint(6) NOT NULL DEFAULT 3,
  `execute_allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace`
--

LOCK TABLES `sys_workspace` WRITE;
/*!40000 ALTER TABLE `sys_workspace` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace_stage`
--

DROP TABLE IF EXISTS `sys_workspace_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_workspace_stage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `responsible_persons` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default_mailcomment` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentid` int(11) NOT NULL DEFAULT 0,
  `parenttable` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notification_defaults` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  `notification_preselection` smallint(6) NOT NULL DEFAULT 8,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace_stage`
--

LOCK TABLES `sys_workspace_stage` WRITE;
/*!40000 ALTER TABLE `sys_workspace_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `category_field` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1668277772,1668273824,3,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"colPos\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,'text','Welcome - This is the TYPO3 Crawler Devbox','','<p>The devbox has close to zero frontend, as most of the functionality is backend related. If there are content examples missing, please create an issue on GitHub.</p>\r\n<p>Here are some links that you might find helpful.</p>\r\n<ul> 	<li>Docs: <a href=\"https://docs.typo3.org/p/tomasnorre/crawler/main/en-us/\">https://docs.typo3.org/p/tomasnorre/crawler/main/en-us/</a></li> 	<li>Issues: <a href=\"https://github.com/tomasnorre/crawler/issues\">https://github.com/tomasnorre/crawler/issues</a></li> 	<li>Repository: <a href=\"https://github.com/tomasnorre/crawler/\">https://github.com/tomasnorre/crawler/</a></li> 	<li>Slack: https://typo3.slack.com/archives/C087NGBKM</li> </ul>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),(2,'',2,1668274063,1668274052,3,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"list_type\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'list','Search','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','indexedsearch_pi2',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),(3,'',3,1668274297,1668274287,3,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'felogin_login','Login','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.showForgotPassword\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.showPermaLogin\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.showLogoutFormAfterLogin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.pages\">\n                    <value index=\"vDEF\">4</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_redirect\">\n            <language index=\"lDEF\">\n                <field index=\"settings.redirectMode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectFirstMethod\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.redirectPageLogin\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectPageLoginError\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectPageLogout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.redirectDisable\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"s_messages\">\n            <language index=\"lDEF\">\n                <field index=\"settings.welcome_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.welcome_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.success_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.error_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.status_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.logout_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_header\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.forgot_reset_message\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,0,NULL,0,0),(4,'',5,1668274404,1668274404,3,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'textpic','Access Restricted Page','','<p>This page should not be visible to you if not logged in.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0),(5,'',11,1671204031,1668275690,3,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'news_pi1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"switchableControllerActions\">\n                    <value index=\"vDEF\">News-&gt;list;News-&gt;detail</value>\n                </field>\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,0,NULL,0,0),(6,'',1,1671284993,1671284660,0,0,0,0,0,'',512,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'html','','','<button onclick=\"myFunction()\">Try it</button>\r\n\r\n<p id=\"demo\"></p>\r\n\r\n<script>\r\nfunction myFunction() {\r\n  let text = \"Press a button!\\nEither OK or Cancel.\";\r\n  if (confirm(text) == true) {\r\n    text = \"You pressed OK!\";\r\n  } else {\r\n    text = \"You canceled!\";\r\n  }\r\n  document.getElementById(\"demo\").innerHTML = text;\r\n}\r\n</script>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_crawler_configuration`
--

DROP TABLE IF EXISTS `tx_crawler_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_crawler_configuration` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `name` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `force_ssl` smallint(6) NOT NULL DEFAULT 0,
  `processing_instruction_filter` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `processing_instruction_parameters_ts` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `configuration` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_url` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pidsonly` blob DEFAULT NULL,
  `begroups` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `fegroups` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `exclude` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_crawler_configuration`
--

LOCK TABLES `tx_crawler_configuration` WRITE;
/*!40000 ALTER TABLE `tx_crawler_configuration` DISABLE KEYS */;
INSERT INTO `tx_crawler_configuration` VALUES (1,1,1668274940,1668274940,3,0,0,'default',0,'tx_indexedsearch_reindex','','','https://crawler-devbox.ddev.site','','','',''),(2,1,1668276574,1668276574,2,0,0,'excludepages-6-plus-3',0,'','','','','','','','6+3'),(3,1,1671199313,1671197316,0,1,0,'testing',0,'','','','','','','',''),(4,1,1671199318,1671198208,0,1,0,'sdfasdf',0,'','','','','','','',''),(5,1,1671199321,1671198680,0,1,0,'testconfiguration',0,'','','','','','','',''),(6,1,1671199324,1671198799,0,1,0,'testconfiguration',0,'','','','','','','',''),(7,1,1671199337,1671199331,2,1,0,'dsfasdfsdaf',0,'','','','','','','',''),(8,1,1671204046,1671203977,0,1,0,'testconfiguration',0,'','','','','','','',''),(9,1,1671267726,1671267726,0,0,0,'testconfiguration',0,'','','','','','','',''),(10,1,1671272191,1671272191,0,0,0,'testconfiguration',0,'','','','','','','',''),(11,1,1671272292,1671272292,0,0,0,'testconfiguration',0,'','','','','','','',''),(12,1,1671272333,1671272333,0,0,0,'testconfiguration',0,'','','','','','','',''),(13,1,1671274160,1671274160,0,0,0,'testconfiguration',0,'','','','','','','',''),(14,1,1671274449,1671274449,0,0,0,'testconfiguration',0,'','','','','','','','');
/*!40000 ALTER TABLE `tx_crawler_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_crawler_process`
--

DROP TABLE IF EXISTS `tx_crawler_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_crawler_process` (
  `process_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `active` smallint(6) DEFAULT 0,
  `ttl` int(11) NOT NULL DEFAULT 0,
  `assigned_items_count` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `system_process_id` int(11) NOT NULL DEFAULT 0,
  KEY `update_key` (`active`,`deleted`),
  KEY `process_id` (`process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_crawler_process`
--

LOCK TABLES `tx_crawler_process` WRITE;
/*!40000 ALTER TABLE `tx_crawler_process` DISABLE KEYS */;
INSERT INTO `tx_crawler_process` VALUES ('7730bdff8aff36ead5cd5ef7bb0d9c6f',0,1671274309,5,0,4191),('1d57e28cb2a2aab18c53ade793e5df5d',0,1671274320,5,0,4222),('4354bdf1ba408efa7d9c81a13ad12497',0,1671274333,1,0,4260),('42b9f7501dd115240a46e73bf51303de',0,1671274595,5,0,4738),('bbc47f11e03fa86e2285292ddfd3c33a',0,1671274606,5,0,4804),('3a7e5aafa910601e08785a31b6951a3e',0,1671274617,1,0,4835);
/*!40000 ALTER TABLE `tx_crawler_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_crawler_queue`
--

DROP TABLE IF EXISTS `tx_crawler_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_crawler_queue` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL DEFAULT 0,
  `parameters` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `parameters_hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `configuration_hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `scheduled` int(11) NOT NULL DEFAULT 0,
  `exec_time` int(11) NOT NULL DEFAULT 0,
  `set_id` int(11) NOT NULL DEFAULT 0,
  `result_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `process_scheduled` int(11) NOT NULL DEFAULT 0,
  `process_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `process_id_completed` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `configuration` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`qid`),
  KEY `page_id` (`page_id`),
  KEY `set_id` (`set_id`),
  KEY `exec_time` (`exec_time`),
  KEY `scheduled` (`scheduled`),
  KEY `process_id` (`process_id`),
  KEY `parameters_hash` (`parameters_hash`),
  KEY `configuration_hash` (`configuration_hash`),
  KEY `cleanup` (`exec_time`,`scheduled`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_crawler_queue`
--

LOCK TABLES `tx_crawler_queue` WRITE;
/*!40000 ALTER TABLE `tx_crawler_queue` DISABLE KEYS */;
INSERT INTO `tx_crawler_queue` VALUES (35,1,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','e07674c94bbf6700a452a6aa3c2010c6','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(36,1,'{\"url\":\"\\/\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','ac026b4c0fa3d9b7a3c0020087f2bb8c','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(37,2,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/search\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','78b2714904e1014856b1a2a6de44aebc','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(38,2,'{\"url\":\"\\/search\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','f654d1bcc6d84bf0452a7df993ef1f60','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(39,3,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/login\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','b95e01b6d9c5c744f2d575bd15e87ebe','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(40,3,'{\"url\":\"\\/login\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','4e717e8a2aabd00d20c6bfc3d32db1ad','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(41,11,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/news\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','f70dcd93f6e4d43cef86b88e004f94e1','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(42,11,'{\"url\":\"\\/news\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','1af3b4d1d8e3bf395ff771f10015e9bf','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(43,7,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/page-with-subpages\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','fd44f32f73f351408a4a0b8ae359ef62','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(44,7,'{\"url\":\"\\/page-with-subpages\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','5a14f61d6534cfb11c71bf2bec196159','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(45,8,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/page-with-subpages\\/subpage-one\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','193012e158c0cce964ef4217dd452d7c','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(46,8,'{\"url\":\"\\/page-with-subpages\\/subpage-one\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','bec0283f18e7d91b048e7b7df61eb5d6','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(47,9,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/page-with-subpages\\/subpage-two\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','deaffb637c906c58ec478da9b2bca3c0','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(48,9,'{\"url\":\"\\/page-with-subpages\\/subpage-two\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','ad33a49064090a4bd4c3008132b58ac2','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(49,10,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/page-with-subpages\\/subpage-three\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','9a625e2c234da4384e0443ce002c21a8','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(50,10,'{\"url\":\"\\/page-with-subpages\\/subpage-three\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','75de8c5921636b8b17c1a6b3c0666d36','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3'),(51,5,'{\"url\":\"https:\\/\\/crawler-devbox.ddev.site\\/access-restricted-page\",\"procInstructions\":[\"tx_indexedsearch_reindex\"],\"procInstrParams\":[]}','b7622971e3e2b7f466e4de8dbf0ede2f','f819546abb32e39a51760fcf2b441f76',1671285911,0,245728511,'',0,'','','default'),(52,5,'{\"url\":\"\\/access-restricted-page\",\"procInstructions\":[\"\"],\"procInstrParams\":[]}','c2ca28ae77597d21ab828a6bcaee711a','f4a729ca165573b3c763abbef261af7f',1671285911,0,245728511,'',0,'','','excludepages-6-plus-3');
/*!40000 ALTER TABLE `tx_crawler_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ter',
  `version` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `distribution_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `distribution_welcome_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_linkvalidator_link`
--

DROP TABLE IF EXISTS `tx_linkvalidator_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_linkvalidator_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT -1,
  `headline` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `element_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_title` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `url_response` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_check` int(11) NOT NULL DEFAULT 0,
  `link_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `needs_recheck` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_linkvalidator_link`
--

LOCK TABLES `tx_linkvalidator_link` WRITE;
/*!40000 ALTER TABLE `tx_linkvalidator_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_linkvalidator_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_source` int(11) NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` smallint(6) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` smallint(6) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_source` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `starttime` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `fe_group` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `teaser` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_email` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `related_files` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `media` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `externalurl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternative_title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sitemap_changefreq` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `import_source` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `sys_language_uid_l10n_parent` (`sys_language_uid`,`l10n_parent`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_ttcontent_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_ttcontent_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news_ttcontent_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_ttcontent_mm`
--

LOCK TABLES `tx_news_domain_model_news_ttcontent_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_source` int(11) NOT NULL DEFAULT 0,
  `t3ver_oid` int(11) NOT NULL DEFAULT 0,
  `t3ver_wsid` int(11) NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` smallint(6) NOT NULL DEFAULT 0,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(11) NOT NULL DEFAULT 0,
  `t3_origuid` int(11) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_count` int(11) NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(11) NOT NULL DEFAULT 0,
  `t3ver_move_id` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `seo_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_headline` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `seo_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastexecution_context` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-18  9:40:04
